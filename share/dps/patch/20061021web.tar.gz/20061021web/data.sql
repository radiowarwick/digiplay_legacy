--
-- PostgreSQL database dump
--

SET client_encoding = 'UTF8';
SET check_function_bodies = false;
SET client_min_messages = warning;

SET search_path = public, pg_catalog;

--
-- Name: cmscontent_contentid_seq; Type: SEQUENCE SET; Schema: public; Owner: www-data
--

SELECT pg_catalog.setval(pg_catalog.pg_get_serial_sequence('cmscontent', 'contentid'), 6, true);


--
-- Data for Name: cmscontent; Type: TABLE DATA; Schema: public; Owner: www-data
--

COPY cmscontent (contentid, regionid, "timestamp", content, userid) FROM stdin;
2	1	1158686156	Hello	2
1	1	1158689819	Hello	4
3	2	1159182375		0
2	2	1159182927	Hahahaha	4
4	3	1159182375		0
5	4	1159182375		0
6	5	1159182375		0
\.


--
-- PostgreSQL database dump complete
--

--
-- PostgreSQL database dump
--

SET client_encoding = 'UTF8';
SET check_function_bodies = false;
SET client_min_messages = warning;

SET search_path = public, pg_catalog;

--
-- Name: cmsregions_regionid_seq; Type: SEQUENCE SET; Schema: public; Owner: www-data
--

SELECT pg_catalog.setval(pg_catalog.pg_get_serial_sequence('cmsregions', 'regionid'), 5, true);


--
-- Data for Name: cmsregions; Type: TABLE DATA; Schema: public; Owner: www-data
--

COPY cmsregions (regionid, name, editrealm, viewrealm, inlinetoolbar, windowtoolbar) FROM stdin;
1	Help Page	71	56	cms_simple	cms_safe
3	Sue Page	74	56	cms_simple	cms_safe
4	Studio Page	75	56	cms_simple	cms_safe
5	Show Page	75	56	cms_simple	cms_safe
2	Music Page	76	56	cms_simple	cms_safe
\.


--
-- PostgreSQL database dump complete
--

--
-- PostgreSQL database dump
--

SET client_encoding = 'UTF8';
SET check_function_bodies = false;
SET client_min_messages = warning;

SET search_path = public, pg_catalog;

--
-- Data for Name: fieldvalidators; Type: TABLE DATA; Schema: public; Owner: www-data
--

COPY fieldvalidators (ruleid, vrclassname, description, modulename) FROM stdin;
1	EmailValidator	Validate an email address	MVC
3	AttemptLogin	Attempt to login username/password (user taken from $fieldData)	Auth
4	UniqueUsername	Check that a username is unique	Auth
5	NoTemplatesInRealm	Check that a realm does not have any templates within it. This should be used before deletion	Auth
6	NoSubRealmsInRealm	Check that a realm does not conatain any sub/child templates. This should be used before deletion	Auth
7	ValidUnusedTplFile	Check that a template file exists and is not in use	MVC
8	CMSContentValidator	Ensures that a user has only submitted HTML tags that are avaliable on the toolbar shown	CMS
12	IntValidator	Ensures that the data represents an integer	
10	EmptyStringValidator	Ensures that a string is not empty	tkfecommon
11	StringValidator	Ensures that the data represents a string	tkfecommon
13	DPSMusicSearchTypeValidator	Checks if the field is set to (Both, Artist, Title)	DPS
14	DPSRequestTitleValidator	Checks that the field is a string and not set to Title	DPS
15	DPSRequestArtistValidator	Checks that the field is a string and not set to Artist	DPS
16	DPSSystemCartsetEditValidator	Checks system can edit a cartset	DPS
17	DPSSystemCartwallEditValidator	Checks system can edit a cartset	DPS
18	DPSSystemCartEditValidator	Checks system can edit a cartset	DPS
19	DPSUserCartsetEditValidator	Checks user can edit a cartset	DPS
20	DPSUserCartwallEditValidator	Checks user can edit a cartset	DPS
21	DPSUserCartEditValidator	Checks user can edit a cartset	DPS
22	DPSSystemCartsetOwnValidator	Checks system owns a cartset	DPS
23	DPSSystemCartwallOwnValidator	Checks system owns a cartset	DPS
25	DPSSystemCartOwnValidator	Checks system owns a cartset	DPS
26	DPSUserCartsetOwnValidator	Checks user owns a cartset	DPS
27	DPSUserCartwallOwnValidator	Checks user owns a cartset	DPS
28	DPSUserCartOwnValidator	Checks user owns a cartset	DPS
29	DPSSystemCartsetReadValidator	Checks system can read a cartset	DPS
30	DPSUserCartsetReadValidator	Checks user can read a cartset	DPS
31	DPSJAAudioIDValidator	Checks that an audio id isa jingle or advert	DPS
\.


--
-- PostgreSQL database dump complete
--

--
-- PostgreSQL database dump
--

SET client_encoding = 'UTF8';
SET check_function_bodies = false;
SET client_min_messages = warning;

SET search_path = public, pg_catalog;

--
-- Name: formfields_fieldid_seq; Type: SEQUENCE SET; Schema: public; Owner: www-data
--

SELECT pg_catalog.setval(pg_catalog.pg_get_serial_sequence('formfields', 'fieldid'), 51, true);


--
-- Data for Name: formfields; Type: TABLE DATA; Schema: public; Owner: www-data
--

COPY formfields (fieldid, formname, fieldname, ruleid, modulename) FROM stdin;
3	loginForm	authPassword	3	Auth
8	groupRealmForm	rguid	10	Auth
9	groupRealmForm	task	11	Auth
4	groupSelForm	groupToEdit	10	Auth
6	groupDeleteForm	groupToEdit	10	Auth
5	groupDetailsForm	groupToEdit	10	Auth
1	dpsloginForm	authPassword	3	Auth
11	dpsMusicSearchForm	dpsSearchType	13	DPS
12	dpsMusicRequestForm	artist	15	DPS
13	dpsMusicRequestForm	title	14	DPS
14	dpsStationActCartsetForm	cartset	29	DPS
15	dpsStationDelCartsetForm	cartset	22	DPS
16	dpsStationAddCartwallPageForm	cartset	16	DPS
17	dpsStationCartwallEditForm	cartset	16	DPS
18	dpsStationCartAddForm	cartwallID	17	DPS
21	dpsStationCartEditForm	cartID	18	DPS
22	dpsUserDelCartsetForm	cartset	26	DPS
23	dpsUserActCartsetForm	cartset	30	DPS
27	dpsStationCartDelForm	cartID	18	DPS
28	dpsUserAddCartwallPageForm	cartset	19	DPS
29	dpsUserCartwallEditForm	cartset	19	DPS
30	dpsUserCartDelForm	cartID	21	DPS
2	dpsMusicSearchForm	dpsSearchVal	10	DPS
32	dpsSueSearchForm	dpsSearchType	13	DPS
31	dpsSueSearchForm	dpsSearchVal	10	DPS
33	dpsMusicCommentForm	comment	10	DPS
34	dpsEditTrackForm	title	10	DPS
35	dpsEditTrackForm	origin	10	DPS
36	dpsUserNewCartsetForm	name	10	DPS
37	dpsUserNewCartsetForm	desc	11	DPS
38	dpsUserCartwallEditForm	desc	11	DPS
39	dpsUserCartwallEditForm	name	10	DPS
40	dpsStationNewCartsetForm	name	10	DPS
41	dpsStationNewCartsetForm	desc	11	DPS
42	dpsStationCartwallEditForm	desc	11	DPS
43	dpsStationCartwallEditForm	name	10	DPS
44	dpsUserCartEditForm	text	10	DPS
45	dpsUserCartEditForm	audioID	31	DPS
46	dpsUserCartAddForm	text	10	DPS
47	dpsUserCartAddForm	audioID	31	DPS
48	dpsStationCartEditForm	text	10	DPS
49	dpsStationCartEditForm	audioID	31	DPS
50	dpsStationCartAddForm	text	10	DPS
51	dpsStationCartAddForm	audioID	31	DPS
\.


--
-- PostgreSQL database dump complete
--

--
-- PostgreSQL database dump
--

SET client_encoding = 'UTF8';
SET check_function_bodies = false;
SET client_min_messages = warning;

SET search_path = public, pg_catalog;

--
-- Name: forms_formid_seq; Type: SEQUENCE SET; Schema: public; Owner: www-data
--

SELECT pg_catalog.setval(pg_catalog.pg_get_serial_sequence('forms', 'formid'), 68, true);


--
-- Data for Name: forms; Type: TABLE DATA; Schema: public; Owner: www-data
--

COPY forms (formid, formname, modelclass, modulename, realmid, validatorname, validatormodule) FROM stdin;
19	selectRegionForm	EditContentModel	CMS	8	\N	\N
20	regionModifyForm	EditContentModel	CMS	8	\N	\N
31	dpsMusicSearchViewForm	DPSViewTracksModel	DPS	56	\N	\N
3	groupDetailsForm	GroupModel	Auth	1	\N	\N
6	groupSelForm	GroupModel	Auth	1	\N	\N
4	groupRealmForm	GroupModel	Auth	1	\N	\N
7	addGroupForm	GroupModel	Auth	1	\N	\N
8	groupDeleteForm	GroupModel	Auth	1	\N	\N
10	addRealmSelForm	RealmModel	Auth	1	\N	\N
14	modifyRealmDetailsForm	RealmModel	Auth	1	\N	\N
11	realmDeleteForm	RealmModel	Auth	1	\N	\N
12	addRealmDetailsForm	RealmModel	Auth	1	\N	\N
13	realmDeleteForm	RealmModel	Auth	1	\N	\N
15	userPermissionForm	UserModel	Auth	1	\N	\N
18	userDeleteForm	UserModel	Auth	1	\N	\N
17	modifyUserDetailsForm	UserModel	Auth	1	\N	\N
16	addUserDetailsForm	UserModel	Auth	1	\N	\N
39	dpsMusicReportForm	DPSReportTrackModel	DPS	64	\N	\N
32	dpsEditTrackForm	DPSEditTrackModel	DPS	61	\N	\N
33	dpsMusicRequestForm	DPSRequestTrackModel	DPS	63	\N	\N
34	dpsMusicRemoveRequestForm	DPSMusicRemoveRequestModel	DPS	67	\N	\N
35	dpsMusicCommentForm	DPSCommentTrackModel	DPS	61	\N	\N
36	dpsMusicDeleteCommentForm	DPSDeleteCommentTrackModel	DPS	61	\N	\N
37	dpsSuePlaylistForm	DPSRemoveSueTrackModel	DPS	66	\N	\N
38	dpsSueAddPlaylistForm	DPSAddSueTrackModel	DPS	66	\N	\N
40	dpsTrackAddCensorForm	DPSAddCensorTrackModel	DPS	65	\N	\N
41	dpsTrackCensorForm	DPSCensorTrackModel	DPS	65	\N	\N
56	dpsMusicDeleteCommentForm	DPSDeleteCommentTrackModel	DPS	61	\N	\N
57	dpsMusicDeleteForm	DPSDeleteTrackModel	DPS	68	\N	\N
30	dpsloginForm	DPSLoginModel	DPS	55	\N	\N
27	inlineEdit	EditInlineModel	CMS	8	\N	\N
59	dpsUserDelCartsetForm	DPSUserDeleteCartsetModel	DPS	56	\N	\N
58	dpsUserActCartsetForm	DPSUserUpdateActCartsetModel	DPS	56	\N	\N
54	dpsUserNewCartsetForm	DPSUserAddCartsetModel	DPS	56	\N	\N
53	dpsUserCartwallEditForm	DPSUserUpdateCartwallModel	DPS	56	\N	\N
55	dpsUserAddCartwallPageForm	DPSUserAddCartPageModel	DPS	56	\N	\N
52	dpsUserCartAddForm	DPSUserAddCartModel	DPS	56	\N	\N
51	dpsUserCartEditForm	DPSUserUpdateCartModel	DPS	56	\N	\N
60	dpsStationNewCartsetForm	DPSStationAddCartsetModel	DPS	70	\N	\N
61	dpsStationDelCartsetForm	DPSStationDeleteCartsetModel	DPS	70	\N	\N
62	dpsStationActCartsetForm	DPSStationUpdateActCartsetModel	DPS	70	\N	\N
63	dpsStationCartwallEditForm	DPSStationUpdateCartwallModel	DPS	70	\N	\N
64	dpsStationAddCartwallPageForm	DPSStationAddCartPageModel	DPS	70	\N	\N
65	dpsStationCartEditForm	DPSStationUpdateCartModel	DPS	70	\N	\N
66	dpsStationCartAddForm	DPSStationAddCartModel	DPS	70	\N	\N
67	dpsStationCartDelForm	DPSStationDeleteCartModel	DPS	70	\N	\N
68	dpsUserCartDelForm	DPSUserDeleteCartModel	DPS	56	\N	\N
\.


--
-- PostgreSQL database dump complete
--

--
-- PostgreSQL database dump
--

SET client_encoding = 'UTF8';
SET check_function_bodies = false;
SET client_min_messages = warning;

SET search_path = public, pg_catalog;

--
-- Name: logentries_entryid_seq; Type: SEQUENCE SET; Schema: public; Owner: www-data
--

SELECT pg_catalog.setval(pg_catalog.pg_get_serial_sequence('logentries', 'entryid'), 1, false);


--
-- Data for Name: logentries; Type: TABLE DATA; Schema: public; Owner: www-data
--

COPY logentries (entryid, message, "level", module, notes, notify_date) FROM stdin;
2424	Checking access to requested template	warning	debug		2006-07-23 21:53:23.028602
2425	Access granted, forwarding user to dpshome.tpl	warning	debug		2006-07-23 21:53:23.040598
2426	Checking access to requested template	warning	debug		2006-07-23 21:59:59.473927
2427	Access granted, forwarding user to dpshome.tpl	warning	debug		2006-07-23 21:59:59.543699
2285	Template access for user: visitor for templateID: 47 is 	debug	Auth		2006-07-19 10:44:23.530711
2286	Auth failed for user 'visitor', template id '47'	debug	MVC		2006-07-19 10:44:23.534202
2287	Source returned for remplate '/var/www/toolkit/DPS/templates/dpspermissionError.tpl'	debug	MVC		2006-07-19 10:44:23.551794
2288	session constructor called Array\n(\n)\n	debug	Session		2006-07-19 10:44:33.616612
2289	Session key 1:, Session key 2	debug	Session		2006-07-19 10:44:33.627597
2290	Creating session values	debug	Session		2006-07-19 10:44:33.63058
2291	session created with id 406	debug	Session		2006-07-19 10:44:33.636901
2292	Checking session for valid login(Auth)	debug	Auth		2006-07-19 10:44:33.643576
2293	No valid session found, user '' now logged in	debug	Auth		2006-07-19 10:44:33.648569
2294	Logging in user as default(Form Login)	debug	MVC		2006-07-19 10:44:33.651685
2295	Settinig session value, details: sessionid=406, skey=auth_user, value=visitor	debug	Session		2006-07-19 10:44:33.659316
2296	Settinig session value, details: sessionid=406, skey=auth_lastRequestTime, value=1153302273	debug	Session		2006-07-19 10:44:33.668592
2297	Checking User access for form:'dpsloginForm', realm:'55', user:'2'	debug	MVC		2006-07-19 10:44:33.677356
2298	checking login for 'psharpe'	debug	MVC		2006-07-19 10:44:33.689572
2299	psharpe has successfully authenticated password	debug	AuthLDAP		2006-07-19 10:44:33.718556
2300	Setting session vars for user 'psharpe'	debug	Auth		2006-07-19 10:44:33.720554
2301	visitor	debug	Auth		2006-07-19 10:44:33.724295
2302	Settinig session value, details: sessionid=406, skey=auth_user, value=psharpe	debug	Session		2006-07-19 10:44:33.729692
2303	psharpe	debug	Auth		2006-07-19 10:44:33.739584
2304	Settinig session value, details: sessionid=406, skey=auth_lastRequestTime, value=1153302273	debug	Session		2006-07-19 10:44:33.746594
2305	successful login for 'psharpe'	debug	MVC		2006-07-19 10:44:33.754563
2306	psharpe	debug	tkfecommon		2006-07-19 10:44:33.75762
2307	Attempting Login (checkAuth)	debug	MVC		2006-07-19 10:44:33.761553
2308	Logging in based on session data - psharpe	debug	Auth		2006-07-19 10:44:33.763661
2309	Settinig session value, details: sessionid=406, skey=auth_lastRequestTime, value=1153302273	debug	Session		2006-07-19 10:44:33.768544
2310	logged in as 'psharpe'	debug	MVC		2006-07-19 10:44:33.773536
2311	Checking template access for user: psharpe for templateID: 46	debug	Auth		2006-07-19 10:44:33.77754
2312	Template access for user: psharpe for templateID: 46 is 1	debug	Auth		2006-07-19 10:44:33.785965
2313	Auth successfull for model for template: '46'	debug	MVC		2006-07-19 10:44:33.788513
2314	Checking access to requested template	warning	debug		2006-07-19 10:44:33.793663
2315	Checking template access for user: 321667 for templateID: 47	debug	Auth		2006-07-19 10:44:33.797516
2316	Template access for user: 321667 for templateID: 47 is 1	debug	Auth		2006-07-19 10:44:33.83247
2317	Access granted, forwarding user to dpshome.tpl	warning	debug		2006-07-19 10:44:33.832488
2318	session constructor called Array\n(\n)\n	debug	Session		2006-07-19 10:44:33.888532
2319	Session key 1:, Session key 2	debug	Session		2006-07-19 10:44:33.89053
2320	Creating session values	debug	Session		2006-07-19 10:44:33.89053
2321	session created with id 407	debug	Session		2006-07-19 10:44:33.891527
2322	Checking session for valid login(Auth)	debug	Auth		2006-07-19 10:44:33.891529
2323	No valid session found, user '' now logged in	debug	Auth		2006-07-19 10:44:33.891529
2324	Logging in user as default (checkAuth)	debug	MVC		2006-07-19 10:44:33.893217
2325	Settinig session value, details: sessionid=407, skey=auth_user, value=visitor	debug	Session		2006-07-19 10:44:33.894525
2326	Settinig session value, details: sessionid=407, skey=auth_lastRequestTime, value=1153302273	debug	Session		2006-07-19 10:44:33.899653
2327	logged in as 'visitor'	debug	MVC		2006-07-19 10:44:33.902512
2328	Checking template access for user: visitor for templateID: 47	debug	Auth		2006-07-19 10:44:33.902514
2329	Template access for user: visitor for templateID: 47 is 	debug	Auth		2006-07-19 10:44:33.904511
2330	Auth failed for user 'visitor', template id '47'	debug	MVC		2006-07-19 10:44:33.904511
2331	Source returned for remplate '/var/www/toolkit/DPS/templates/dpspermissionError.tpl'	debug	MVC		2006-07-19 10:44:33.908502
2332	session constructor called Array\n(\n)\n	debug	Session		2006-07-19 10:44:43.170802
2333	Session key 1:, Session key 2	debug	Session		2006-07-19 10:44:43.192119
2334	Creating session values	debug	Session		2006-07-19 10:44:43.19912
2335	session created with id 408	debug	Session		2006-07-19 10:44:43.201986
2336	Checking session for valid login(Auth)	debug	Auth		2006-07-19 10:44:43.201986
2337	No valid session found, user '' now logged in	debug	Auth		2006-07-19 10:44:43.201986
2338	Logging in user as default(Form Login)	debug	MVC		2006-07-19 10:44:43.201986
2339	Settinig session value, details: sessionid=408, skey=auth_user, value=visitor	debug	Session		2006-07-19 10:44:43.205966
2340	Settinig session value, details: sessionid=408, skey=auth_lastRequestTime, value=1153302283	debug	Session		2006-07-19 10:44:43.20598
2341	Checking User access for form:'dpsloginForm', realm:'55', user:'2'	debug	MVC		2006-07-19 10:44:43.20598
2342	checking login for 'psharpe'	debug	MVC		2006-07-19 10:44:43.208984
2343	psharpe has successfully authenticated password	debug	AuthLDAP		2006-07-19 10:44:43.229986
2344	Setting session vars for user 'psharpe'	debug	Auth		2006-07-19 10:44:43.230001
2345	visitor	debug	Auth		2006-07-19 10:44:43.230005
2346	Settinig session value, details: sessionid=408, skey=auth_user, value=psharpe	debug	Session		2006-07-19 10:44:43.230007
2347	psharpe	debug	Auth		2006-07-19 10:44:43.230007
2348	Settinig session value, details: sessionid=408, skey=auth_lastRequestTime, value=1153302283	debug	Session		2006-07-19 10:44:43.234828
2349	successful login for 'psharpe'	debug	MVC		2006-07-19 10:44:43.235995
2350	psharpe	debug	tkfecommon		2006-07-19 10:44:43.235998
2351	Attempting Login (checkAuth)	debug	MVC		2006-07-19 10:44:43.235998
2352	Logging in based on session data - psharpe	debug	Auth		2006-07-19 10:44:43.237166
2353	Settinig session value, details: sessionid=408, skey=auth_lastRequestTime, value=1153302283	debug	Session		2006-07-19 10:44:43.242975
2354	logged in as 'psharpe'	debug	MVC		2006-07-19 10:44:43.242988
2355	Checking template access for user: psharpe for templateID: 46	debug	Auth		2006-07-19 10:44:43.242989
2356	Template access for user: psharpe for templateID: 46 is 1	debug	Auth		2006-07-19 10:44:43.246975
2357	Auth successfull for model for template: '46'	debug	MVC		2006-07-19 10:44:43.246982
2358	Checking access to requested template	warning	debug		2006-07-19 10:44:43.249976
2359	Checking template access for user: 321667 for templateID: 47	debug	Auth		2006-07-19 10:44:43.249978
2360	Template access for user: 321667 for templateID: 47 is 1	debug	Auth		2006-07-19 10:44:43.303891
2361	Access granted, forwarding user to dpshome.tpl	warning	debug		2006-07-19 10:44:43.303906
2362	session constructor called Array\n(\n)\n	debug	Session		2006-07-19 10:44:43.371906
2363	Session key 1:, Session key 2	debug	Session		2006-07-19 10:44:43.371906
2364	Creating session values	debug	Session		2006-07-19 10:44:43.371906
2365	session created with id 409	debug	Session		2006-07-19 10:44:43.373902
2366	Checking session for valid login(Auth)	debug	Auth		2006-07-19 10:44:43.373903
2367	No valid session found, user '' now logged in	debug	Auth		2006-07-19 10:44:43.373903
2368	Logging in user as default (checkAuth)	debug	MVC		2006-07-19 10:44:43.376895
2369	Settinig session value, details: sessionid=409, skey=auth_user, value=visitor	debug	Session		2006-07-19 10:44:43.376913
2370	Settinig session value, details: sessionid=409, skey=auth_lastRequestTime, value=1153302283	debug	Session		2006-07-19 10:44:43.378879
2371	logged in as 'visitor'	debug	MVC		2006-07-19 10:44:43.379897
2372	Checking template access for user: visitor for templateID: 47	debug	Auth		2006-07-19 10:44:43.379907
2373	Template access for user: visitor for templateID: 47 is 	debug	Auth		2006-07-19 10:44:43.384896
2374	Auth failed for user 'visitor', template id '47'	debug	MVC		2006-07-19 10:44:43.384901
2375	Source returned for remplate '/var/www/toolkit/DPS/templates/dpspermissionError.tpl'	debug	MVC		2006-07-19 10:44:43.390889
2376	session constructor called Array\n(\n)\n	debug	Session		2006-07-19 10:44:54.24062
2377	Session key 1:, Session key 2	debug	Session		2006-07-19 10:44:54.2566
2378	Creating session values	debug	Session		2006-07-19 10:44:54.257599
2379	session created with id 410	debug	Session		2006-07-19 10:44:54.265015
2380	Checking session for valid login(Auth)	debug	Auth		2006-07-19 10:44:54.269593
2381	No valid session found, user '' now logged in	debug	Auth		2006-07-19 10:44:54.272584
2382	Logging in user as default (checkAuth)	debug	MVC		2006-07-19 10:44:54.274592
2383	Settinig session value, details: sessionid=410, skey=auth_user, value=visitor	debug	Session		2006-07-19 10:44:54.280588
2384	Settinig session value, details: sessionid=410, skey=auth_lastRequestTime, value=1153302294	debug	Session		2006-07-19 10:44:54.283602
2385	logged in as 'visitor'	debug	MVC		2006-07-19 10:44:54.283604
2386	Checking template access for user: visitor for templateID: 46	debug	Auth		2006-07-19 10:44:54.288757
2387	Template access for user: visitor for templateID: 46 is 1	debug	Auth		2006-07-19 10:44:54.302606
2388	Auth successfull for model for template: '46'	debug	MVC		2006-07-19 10:44:54.302616
2389	Source returned for remplate '/var/www/toolkit/DPS/templates/dpslogin.tpl'	debug	MVC		2006-07-19 10:44:54.320559
2390	session constructor called Array\n(\n    [test1] => 91\n)\n	debug	Session		2006-07-19 10:45:35.452785
2391	Session key 1:, Session key 2	debug	Session		2006-07-19 10:45:35.462233
2392	Creating session values	debug	Session		2006-07-19 10:45:35.466647
2393	session created with id 411	debug	Session		2006-07-19 10:45:35.475637
2394	Checking session for valid login(Auth)	debug	Auth		2006-07-19 10:45:35.482642
2395	No valid session found, user '' now logged in	debug	Auth		2006-07-19 10:45:35.484878
2396	Logging in user as default (checkAuth)	debug	MVC		2006-07-19 10:45:35.490631
2397	Settinig session value, details: sessionid=411, skey=auth_user, value=visitor	debug	Session		2006-07-19 10:45:35.501614
2398	Settinig session value, details: sessionid=411, skey=auth_lastRequestTime, value=1153302335	debug	Session		2006-07-19 10:45:35.51128
2399	logged in as 'visitor'	debug	MVC		2006-07-19 10:45:35.521713
2400	Checking template access for user: visitor for templateID: 46	debug	Auth		2006-07-19 10:45:35.526304
2401	Template access for user: visitor for templateID: 46 is 1	debug	Auth		2006-07-19 10:45:35.542292
2402	Auth successfull for model for template: '46'	debug	MVC		2006-07-19 10:45:35.546285
2403	Source returned for remplate '/var/www/toolkit/DPS/templates/dpslogin.tpl'	debug	MVC		2006-07-19 10:45:35.564844
2128	session constructor called Array\n(\n)\n	debug	Session		2006-07-19 10:41:54.302943
2129	Session key 1:, Session key 2	debug	Session		2006-07-19 10:41:54.31552
2130	Creating session values	debug	Session		2006-07-19 10:41:54.321874
2131	session created with id 398	debug	Session		2006-07-19 10:41:54.326363
2132	Checking session for valid login(Auth)	debug	Auth		2006-07-19 10:41:54.328385
2133	No valid session found, user '' now logged in	debug	Auth		2006-07-19 10:41:54.329263
2134	Logging in user as default(Form Login)	debug	MVC		2006-07-19 10:41:54.330227
2135	Settinig session value, details: sessionid=398, skey=auth_user, value=visitor	debug	Session		2006-07-19 10:41:54.331337
2136	Settinig session value, details: sessionid=398, skey=auth_lastRequestTime, value=1153302114	debug	Session		2006-07-19 10:41:54.333762
2137	Checking User access for form:'dpsloginForm', realm:'55', user:'2'	debug	MVC		2006-07-19 10:41:54.33827
2138	checking login for 'psharpe'	debug	MVC		2006-07-19 10:41:54.340404
2139	psharpe has successfully authenticated password	debug	AuthLDAP		2006-07-19 10:41:54.36745
2140	Setting session vars for user 'psharpe'	debug	Auth		2006-07-19 10:41:54.372827
2141	visitor	debug	Auth		2006-07-19 10:41:54.372843
2142	Settinig session value, details: sessionid=398, skey=auth_user, value=psharpe	debug	Session		2006-07-19 10:41:54.382813
2143	psharpe	debug	Auth		2006-07-19 10:41:54.389151
2144	Settinig session value, details: sessionid=398, skey=auth_lastRequestTime, value=1153302114	debug	Session		2006-07-19 10:41:54.391578
2145	successful login for 'psharpe'	debug	MVC		2006-07-19 10:41:54.398234
2146	psharpe	debug	tkfecommon		2006-07-19 10:41:54.399194
2147	Attempting Login (checkAuth)	debug	MVC		2006-07-19 10:41:54.400299
2148	Logging in based on session data - psharpe	debug	Auth		2006-07-19 10:41:54.401273
2149	Settinig session value, details: sessionid=398, skey=auth_lastRequestTime, value=1153302114	debug	Session		2006-07-19 10:41:54.404116
2150	logged in as 'psharpe'	debug	MVC		2006-07-19 10:41:54.408652
2151	Checking template access for user: psharpe for templateID: 46	debug	Auth		2006-07-19 10:41:54.411005
2404	Checking access to requested template	warning	debug		2006-07-22 00:58:04.220955
2405	Access granted, forwarding user to dpshome.tpl	warning	debug		2006-07-22 00:58:04.2579
2152	Template access for user: psharpe for templateID: 46 is 1	debug	Auth		2006-07-19 10:41:54.412758
2153	Auth successfull for model for template: '46'	debug	MVC		2006-07-19 10:41:54.414697
2154	Checking access to requested template	warning	debug		2006-07-19 10:41:54.415376
2155	Checking template access for user: 321667 for templateID: 47	debug	Auth		2006-07-19 10:41:54.417179
2156	Template access for user: 321667 for templateID: 47 is 1	debug	Auth		2006-07-19 10:41:54.442714
2157	Access granted, forwarding user to dpshome.tpl	warning	debug		2006-07-19 10:41:54.44405
2406	Checking access to requested template	warning	debug		2006-07-23 04:06:31.234881
2407	Access granted, forwarding user to dpshome.tpl	warning	debug		2006-07-23 04:06:31.284046
2158	session constructor called Array\n(\n)\n	debug	Session		2006-07-19 10:41:54.500691
2159	Session key 1:, Session key 2	debug	Session		2006-07-19 10:41:54.504737
2160	Creating session values	debug	Session		2006-07-19 10:41:54.506727
2161	session created with id 399	debug	Session		2006-07-19 10:41:54.515023
2162	Checking session for valid login(Auth)	debug	Auth		2006-07-19 10:41:54.518903
2163	No valid session found, user '' now logged in	debug	Auth		2006-07-19 10:41:54.520757
2164	Logging in user as default (checkAuth)	debug	MVC		2006-07-19 10:41:54.520767
2165	Settinig session value, details: sessionid=399, skey=auth_user, value=visitor	debug	Session		2006-07-19 10:41:54.521896
2166	Settinig session value, details: sessionid=399, skey=auth_lastRequestTime, value=1153302114	debug	Session		2006-07-19 10:41:54.533724
2167	logged in as 'visitor'	debug	MVC		2006-07-19 10:41:54.54274
2168	Checking template access for user: visitor for templateID: 47	debug	Auth		2006-07-19 10:41:54.542742
2169	Template access for user: visitor for templateID: 47 is 	debug	Auth		2006-07-19 10:41:54.542743
2170	Auth failed for user 'visitor', template id '47'	debug	MVC		2006-07-19 10:41:54.542743
2171	Source returned for remplate '/var/www/toolkit/DPS/templates/dpspermissionError.tpl'	debug	MVC		2006-07-19 10:41:54.546736
2408	Checking access to requested template	warning	debug		2006-07-23 04:06:33.295881
2409	Access granted, forwarding user to dpshome.tpl	warning	debug		2006-07-23 04:06:33.376904
2172	session constructor called Array\n(\n)\n	debug	Session		2006-07-19 10:43:03.605236
2173	Session key 1:, Session key 2	debug	Session		2006-07-19 10:43:03.605243
2174	Creating session values	debug	Session		2006-07-19 10:43:03.605245
2175	session created with id 400	debug	Session		2006-07-19 10:43:03.605245
2176	Checking session for valid login(Auth)	debug	Auth		2006-07-19 10:43:03.609239
2177	No valid session found, user '' now logged in	debug	Auth		2006-07-19 10:43:03.609259
2178	Logging in user as default (checkAuth)	debug	MVC		2006-07-19 10:43:03.609264
2179	Settinig session value, details: sessionid=400, skey=auth_user, value=visitor	debug	Session		2006-07-19 10:43:03.609266
2180	Settinig session value, details: sessionid=400, skey=auth_lastRequestTime, value=1153302183	debug	Session		2006-07-19 10:43:03.613261
2181	logged in as 'visitor'	debug	MVC		2006-07-19 10:43:03.613266
2182	Checking template access for user: visitor for templateID: 46	debug	Auth		2006-07-19 10:43:03.613266
2183	Template access for user: visitor for templateID: 46 is 1	debug	Auth		2006-07-19 10:43:03.625169
2184	Auth successfull for model for template: '46'	debug	MVC		2006-07-19 10:43:03.628254
2185	Source returned for remplate '/var/www/toolkit/DPS/templates/dpslogin.tpl'	debug	MVC		2006-07-19 10:43:03.639765
2410	Checking access to requested template	warning	debug		2006-07-23 04:06:35.712736
2411	Access granted, forwarding user to dpshome.tpl	warning	debug		2006-07-23 04:06:35.742884
2186	session constructor called Array\n(\n)\n	debug	Session		2006-07-19 10:43:38.107572
2187	Session key 1:, Session key 2	debug	Session		2006-07-19 10:43:38.123522
2188	Creating session values	debug	Session		2006-07-19 10:43:38.123544
2189	session created with id 401	debug	Session		2006-07-19 10:43:38.130588
2190	Checking session for valid login(Auth)	debug	Auth		2006-07-19 10:43:38.13758
2191	No valid session found, user '' now logged in	debug	Auth		2006-07-19 10:43:38.142521
2192	Logging in user as default (checkAuth)	debug	MVC		2006-07-19 10:43:38.148824
2193	Settinig session value, details: sessionid=401, skey=auth_user, value=visitor	debug	Session		2006-07-19 10:43:38.158525
2194	Settinig session value, details: sessionid=401, skey=auth_lastRequestTime, value=1153302218	debug	Session		2006-07-19 10:43:38.16915
2195	logged in as 'visitor'	debug	MVC		2006-07-19 10:43:38.177146
2196	Checking template access for user: visitor for templateID: 46	debug	Auth		2006-07-19 10:43:38.181141
2197	Template access for user: visitor for templateID: 46 is 1	debug	Auth		2006-07-19 10:43:38.203137
2198	Auth successfull for model for template: '46'	debug	MVC		2006-07-19 10:43:38.207137
2199	Source returned for remplate '/var/www/toolkit/DPS/templates/dpslogin.tpl'	debug	MVC		2006-07-19 10:43:38.222487
2412	Checking access to requested template	warning	debug		2006-07-23 20:04:05.563454
2413	Access granted, forwarding user to dpshome.tpl	warning	debug		2006-07-23 20:04:05.66301
2200	session constructor called Array\n(\n    [test1] => 91\n)\n	debug	Session		2006-07-19 10:43:53.319589
2201	Session key 1:, Session key 2	debug	Session		2006-07-19 10:43:53.33579
2202	Creating session values	debug	Session		2006-07-19 10:43:53.33716
2203	session created with id 402	debug	Session		2006-07-19 10:43:53.339399
2204	Checking session for valid login(Auth)	debug	Auth		2006-07-19 10:43:53.340164
2205	No valid session found, user '' now logged in	debug	Auth		2006-07-19 10:43:53.340169
2206	Logging in user as default(Form Login)	debug	MVC		2006-07-19 10:43:53.34017
2207	Settinig session value, details: sessionid=402, skey=auth_user, value=visitor	debug	Session		2006-07-19 10:43:53.34017
2208	Settinig session value, details: sessionid=402, skey=auth_lastRequestTime, value=1153302233	debug	Session		2006-07-19 10:43:53.34017
2209	Checking User access for form:'dpsloginForm', realm:'55', user:'2'	debug	MVC		2006-07-19 10:43:53.343152
2210	checking login for 'psharpe'	debug	MVC		2006-07-19 10:43:53.349249
2211	psharpe has successfully authenticated password	debug	AuthLDAP		2006-07-19 10:43:53.379287
2212	Setting session vars for user 'psharpe'	debug	Auth		2006-07-19 10:43:53.383135
2213	visitor	debug	Auth		2006-07-19 10:43:53.38514
2214	Settinig session value, details: sessionid=402, skey=auth_user, value=psharpe	debug	Session		2006-07-19 10:43:53.390368
2215	psharpe	debug	Auth		2006-07-19 10:43:53.391143
2216	Settinig session value, details: sessionid=402, skey=auth_lastRequestTime, value=1153302233	debug	Session		2006-07-19 10:43:53.394121
2217	successful login for 'psharpe'	debug	MVC		2006-07-19 10:43:53.39414
2218	psharpe	debug	tkfecommon		2006-07-19 10:43:53.394141
2219	Attempting Login (checkAuth)	debug	MVC		2006-07-19 10:43:53.394142
2220	Logging in based on session data - psharpe	debug	Auth		2006-07-19 10:43:53.398098
2221	Settinig session value, details: sessionid=402, skey=auth_lastRequestTime, value=1153302233	debug	Session		2006-07-19 10:43:53.399131
2222	logged in as 'psharpe'	debug	MVC		2006-07-19 10:43:53.400128
2223	Checking template access for user: psharpe for templateID: 46	debug	Auth		2006-07-19 10:43:53.400133
2414	Checking access to requested template	warning	debug		2006-07-23 20:29:45.064783
2415	Access granted, forwarding user to dpshome.tpl	warning	debug		2006-07-23 20:29:45.142753
2224	Template access for user: psharpe for templateID: 46 is 1	debug	Auth		2006-07-19 10:43:53.400134
2225	Auth successfull for model for template: '46'	debug	MVC		2006-07-19 10:43:53.403169
2226	Checking access to requested template	warning	debug		2006-07-19 10:43:53.409415
2227	Checking template access for user: 321667 for templateID: 47	debug	Auth		2006-07-19 10:43:53.415086
2228	Template access for user: 321667 for templateID: 47 is 1	debug	Auth		2006-07-19 10:43:53.46224
2229	Access granted, forwarding user to dpshome.tpl	warning	debug		2006-07-19 10:43:53.469213
2416	Exception: 	warning	unspecified	Error Code: 0\nFile: /var/www/toolkit/MVC/Page.class.php\nLine: 299\nStack Trace:\n#0 /var/www/toolkit/MVC/Page.class.php(109): Page->loadFieldData()\n#1 /var/www/toolkit/index.php(12): Page->__construct()\n#2 {main}\n	2006-07-23 20:36:43.532915
2230	session constructor called Array\n(\n)\n	debug	Session		2006-07-19 10:43:53.545263
2231	Session key 1:, Session key 2	debug	Session		2006-07-19 10:43:53.551354
2232	Creating session values	debug	Session		2006-07-19 10:43:53.55604
2233	session created with id 403	debug	Session		2006-07-19 10:43:53.557052
2234	Checking session for valid login(Auth)	debug	Auth		2006-07-19 10:43:53.557053
2235	No valid session found, user '' now logged in	debug	Auth		2006-07-19 10:43:53.561761
2236	Logging in user as default (checkAuth)	debug	MVC		2006-07-19 10:43:53.566243
2237	Settinig session value, details: sessionid=403, skey=auth_user, value=visitor	debug	Session		2006-07-19 10:43:53.575232
2238	Settinig session value, details: sessionid=403, skey=auth_lastRequestTime, value=1153302233	debug	Session		2006-07-19 10:43:53.58519
2239	logged in as 'visitor'	debug	MVC		2006-07-19 10:43:53.595233
2240	Checking template access for user: visitor for templateID: 47	debug	Auth		2006-07-19 10:43:53.59969
2241	Template access for user: visitor for templateID: 47 is 	debug	Auth		2006-07-19 10:43:53.611154
2242	Auth failed for user 'visitor', template id '47'	debug	MVC		2006-07-19 10:43:53.615624
2243	Source returned for remplate '/var/www/toolkit/DPS/templates/dpspermissionError.tpl'	debug	MVC		2006-07-19 10:43:53.633348
2417	Exception: 	warning	MVC	Error Code: 0\nFile: /var/www/toolkit/MVC/MVCUtils.class.php\nLine: 114\nStack Trace:\n#0 /var/www/toolkit/MVC/MVCUtils.class.php(74): MVCUtils::includeClass('DPSReportTrackM...', 'DPS', 'models')\n#1 /var/www/toolkit/MVC/MVCUtils.class.php(208): MVCUtils::includeModel('DPSReportTrackM...', 'DPS')\n#2 /var/www/toolkit/MVC/Page.class.php(204): MVCUtils::initializeModel(Array, 'dpsMusicReportF...', 'DPS', 'DPS', Array, Array)\n#3 /var/www/toolkit/index.php(12): Page->__construct()\n#4 {main}\n	2006-07-23 20:36:56.79198
2244	session constructor called Array\n(\n)\n	debug	Session		2006-07-19 10:44:23.133846
2245	Session key 1:, Session key 2	debug	Session		2006-07-19 10:44:23.147967
2246	Creating session values	debug	Session		2006-07-19 10:44:23.153859
2247	session created with id 404	debug	Session		2006-07-19 10:44:23.161744
2248	Checking session for valid login(Auth)	debug	Auth		2006-07-19 10:44:23.163697
2249	No valid session found, user '' now logged in	debug	Auth		2006-07-19 10:44:23.163703
2250	Logging in user as default(Form Login)	debug	MVC		2006-07-19 10:44:23.165683
2251	Settinig session value, details: sessionid=404, skey=auth_user, value=visitor	debug	Session		2006-07-19 10:44:23.165701
2252	Settinig session value, details: sessionid=404, skey=auth_lastRequestTime, value=1153302263	debug	Session		2006-07-19 10:44:23.165704
2253	Checking User access for form:'dpsloginForm', realm:'55', user:'2'	debug	MVC		2006-07-19 10:44:23.165704
2254	checking login for 'psharpe'	debug	MVC		2006-07-19 10:44:23.17868
2255	psharpe has successfully authenticated password	debug	AuthLDAP		2006-07-19 10:44:23.211747
2256	Setting session vars for user 'psharpe'	debug	Auth		2006-07-19 10:44:23.216729
2257	visitor	debug	Auth		2006-07-19 10:44:23.220747
2258	Settinig session value, details: sessionid=404, skey=auth_user, value=psharpe	debug	Session		2006-07-19 10:44:23.227894
2259	psharpe	debug	Auth		2006-07-19 10:44:23.235928
2260	Settinig session value, details: sessionid=404, skey=auth_lastRequestTime, value=1153302263	debug	Session		2006-07-19 10:44:23.241646
2261	successful login for 'psharpe'	debug	MVC		2006-07-19 10:44:23.247632
2262	psharpe	debug	tkfecommon		2006-07-19 10:44:23.249654
2263	Attempting Login (checkAuth)	debug	MVC		2006-07-19 10:44:23.251645
2264	Logging in based on session data - psharpe	debug	Auth		2006-07-19 10:44:23.254641
2265	Settinig session value, details: sessionid=404, skey=auth_lastRequestTime, value=1153302263	debug	Session		2006-07-19 10:44:23.260637
2266	logged in as 'psharpe'	debug	MVC		2006-07-19 10:44:23.265867
2267	Checking template access for user: psharpe for templateID: 46	debug	Auth		2006-07-19 10:44:23.270639
2418	Checking access to requested template	warning	debug		2006-07-23 20:51:46.276383
2419	Access granted, forwarding user to dpshome.tpl	warning	debug		2006-07-23 20:51:46.336339
2268	Template access for user: psharpe for templateID: 46 is 1	debug	Auth		2006-07-19 10:44:23.280274
2269	Auth successfull for model for template: '46'	debug	MVC		2006-07-19 10:44:23.287628
2270	Checking access to requested template	warning	debug		2006-07-19 10:44:23.293903
2271	Checking template access for user: 321667 for templateID: 47	debug	Auth		2006-07-19 10:44:23.30264
2272	Template access for user: 321667 for templateID: 47 is 1	debug	Auth		2006-07-19 10:44:23.366606
2273	Access granted, forwarding user to dpshome.tpl	warning	debug		2006-07-19 10:44:23.366612
2420	Checking access to requested template	warning	debug		2006-07-23 20:51:52.533681
2421	Access granted, forwarding user to dpshome.tpl	warning	debug		2006-07-23 20:51:52.571962
2274	session constructor called Array\n(\n)\n	debug	Session		2006-07-19 10:44:23.455655
2422	Checking access to requested template	warning	debug		2006-07-23 20:59:06.93981
2423	Access granted, forwarding user to dpshome.tpl	warning	debug		2006-07-23 20:59:06.983794
2428	Checking access to requested template	warning	debug		2006-08-10 21:00:57.969632
2429	Access granted, forwarding user to dpshome.tpl	warning	debug		2006-08-10 21:00:58.064301
2430	Checking access to requested template	warning	debug		2006-08-11 19:00:26.139651
2431	Access granted, forwarding user to dpshome.tpl	warning	debug		2006-08-11 19:00:26.213686
2432	Checking access to requested template	warning	debug		2006-08-11 19:52:26.984343
2433	Access granted, forwarding user to dpshome.tpl	warning	debug		2006-08-11 19:52:27.029093
2434	Checking access to requested template	warning	debug		2006-08-20 21:40:36.682995
2435	Access granted, forwarding user to dpshome.tpl	warning	debug		2006-08-20 21:40:36.791053
2436	Checking access to requested template	warning	debug		2006-08-20 21:49:50.185076
2437	Access granted, forwarding user to dpshome.tpl	warning	debug		2006-08-20 21:49:50.251979
2438	Checking access to requested template	warning	debug		2006-08-20 21:51:17.562864
2439	Access granted, forwarding user to dpshome.tpl	warning	debug		2006-08-20 21:51:17.618938
2440	Checking access to requested template	warning	debug		2006-08-20 22:58:07.174076
2441	Access granted, forwarding user to dpshome.tpl	warning	debug		2006-08-20 22:58:07.202551
2442	Checking access to requested template	warning	debug		2006-08-25 21:14:21.211471
2443	Access granted, forwarding user to dpshome.tpl	warning	debug		2006-08-25 21:14:21.259096
2444	Checking access to requested template	warning	debug		2006-08-25 22:17:59.055009
2445	Access granted, forwarding user to dpshome.tpl	warning	debug		2006-08-25 22:17:59.170359
2446	Checking access to requested template	warning	debug		2006-08-25 22:18:50.869738
2447	Access granted, forwarding user to dpshome.tpl	warning	debug		2006-08-25 22:18:50.943252
2448	Checking access to requested template	warning	debug		2006-08-28 17:37:10.203342
2449	Access granted, forwarding user to dpshome.tpl	warning	debug		2006-08-28 17:37:10.255364
2450	Checking access to requested template	warning	debug		2006-08-28 18:27:06.343008
2451	Access granted, forwarding user to dpshome.tpl	warning	debug		2006-08-28 18:27:06.3924
2452	Checking access to requested template	warning	debug		2006-08-28 18:41:45.702571
2453	Access granted, forwarding user to dpshome.tpl	warning	debug		2006-08-28 18:41:45.753986
2454	Checking access to requested template	warning	debug		2006-08-28 19:52:30.14719
2455	Access granted, forwarding user to dpshome.tpl	warning	debug		2006-08-28 19:52:30.221439
2456	Checking access to requested template	warning	debug		2006-08-28 20:56:26.08459
2457	Access granted, forwarding user to dpshome.tpl	warning	debug		2006-08-28 20:56:26.140529
2458	Checking access to requested template	warning	debug		2006-08-28 21:09:21.480331
2459	Access granted, forwarding user to dpshome.tpl	warning	debug		2006-08-28 21:09:21.528338
2460	Checking access to requested template	warning	debug		2006-08-28 23:50:32.758701
2461	Access granted, forwarding user to dpshome.tpl	warning	debug		2006-08-28 23:50:32.837856
2462	Exception: 	warning	MVC	Error Code: 0\nFile: /var/www/toolkit/MVC/MVCUtils.class.php\nLine: 114\nStack Trace:\n#0 /var/www/toolkit/MVC/MVCUtils.class.php(74): MVCUtils::includeClass('DPSUpdateStatio...', 'DPS', 'models')\n#1 /var/www/toolkit/MVC/MVCUtils.class.php(208): MVCUtils::includeModel('DPSUpdateStatio...', 'DPS')\n#2 /var/www/toolkit/MVC/Page.class.php(204): MVCUtils::initializeModel(Array, 'dpsStationActCa...', 'DPS', 'DPS', Array, Array)\n#3 /var/www/toolkit/index.php(12): Page->__construct()\n#4 {main}\n	2006-08-29 00:37:03.801243
2463	Checking access to requested template	warning	debug		2006-08-29 00:50:47.025391
2464	Access granted, forwarding user to dpshome.tpl	warning	debug		2006-08-29 00:50:47.075365
2465	Checking access to requested template	warning	debug		2006-08-29 04:36:52.647109
2466	Access granted, forwarding user to dpshome.tpl	warning	debug		2006-08-29 04:36:52.69726
2275	Session key 1:, Session key 2	debug	Session		2006-07-19 10:44:23.461694
2276	Creating session values	debug	Session		2006-07-19 10:44:23.466539
2277	session created with id 405	debug	Session		2006-07-19 10:44:23.473663
2278	Checking session for valid login(Auth)	debug	Auth		2006-07-19 10:44:23.47922
2279	No valid session found, user '' now logged in	debug	Auth		2006-07-19 10:44:23.482195
2280	Logging in user as default (checkAuth)	debug	MVC		2006-07-19 10:44:23.484792
2281	Settinig session value, details: sessionid=405, skey=auth_user, value=visitor	debug	Session		2006-07-19 10:44:23.4938
2282	Settinig session value, details: sessionid=405, skey=auth_lastRequestTime, value=1153302263	debug	Session		2006-07-19 10:44:23.502509
2283	logged in as 'visitor'	debug	MVC		2006-07-19 10:44:23.511138
2284	Checking template access for user: visitor for templateID: 47	debug	Auth		2006-07-19 10:44:23.515256
2467	Checking access to requested template	warning	debug		2006-08-29 06:22:29.242019
2468	Access granted, forwarding user to dpshome.tpl	warning	debug		2006-08-29 06:22:29.353103
2469	Checking access to requested template	warning	debug		2006-09-01 18:22:22.117754
2470	Access granted, forwarding user to dpshome.tpl	warning	debug		2006-09-01 18:22:22.269464
2471	Checking access to requested template	warning	debug		2006-09-03 18:41:22.560457
2472	Access granted, forwarding user to dpshome.tpl	warning	debug		2006-09-03 18:41:22.596985
2473	Checking access to requested template	warning	debug		2006-09-03 19:48:01.670068
2474	Access granted, forwarding user to dpshome.tpl	warning	debug		2006-09-03 19:48:01.690017
2475	Checking access to requested template	warning	debug		2006-09-08 22:01:09.246623
2476	Access granted, forwarding user to dpshome.tpl	warning	debug		2006-09-08 22:01:09.309808
2477	Checking access to requested template	warning	debug		2006-09-10 16:23:13.45176
2478	Access granted, forwarding user to dpshome.tpl	warning	debug		2006-09-10 16:23:13.467368
2479	Checking access to requested template	warning	debug		2006-09-10 17:36:33.698451
2480	Access granted, forwarding user to dpshome.tpl	warning	debug		2006-09-10 17:36:33.71482
2481	Checking access to requested template	warning	debug		2006-09-10 18:39:11.918589
2482	Access granted, forwarding user to dpshome.tpl	warning	debug		2006-09-10 18:39:11.982669
2483	Checking access to requested template	warning	debug		2006-09-10 19:43:30.092243
2484	Access granted, forwarding user to dpshome.tpl	warning	debug		2006-09-10 19:43:30.107558
2485	Checking access to requested template	warning	debug		2006-09-10 20:43:32.090995
2486	Access granted, forwarding user to dpshome.tpl	warning	debug		2006-09-10 20:43:32.108202
2487	Checking access to requested template	warning	debug		2006-09-10 21:28:03.610437
2488	Access granted, forwarding user to dpshome.tpl	warning	debug		2006-09-10 21:28:03.626384
2489	Checking access to requested template	warning	debug		2006-09-10 21:49:51.728907
2490	Access granted, forwarding user to dpshome.tpl	warning	debug		2006-09-10 21:49:51.744298
2491	Checking access to requested template	warning	debug		2006-09-10 23:02:59.959067
2492	Access granted, forwarding user to dpshome.tpl	warning	debug		2006-09-10 23:02:59.974267
2493	Checking access to requested template	warning	debug		2006-09-10 23:20:33.263913
2494	Access granted, forwarding user to dpshome.tpl	warning	debug		2006-09-10 23:20:33.278838
2495	Checking access to requested template	warning	debug		2006-09-10 23:37:03.560105
2496	Access granted, forwarding user to dpshome.tpl	warning	debug		2006-09-10 23:37:03.574008
2497	Checking access to requested template	warning	debug		2006-09-10 23:42:26.780168
2498	Access granted, forwarding user to dpshome.tpl	warning	debug		2006-09-10 23:42:26.819694
2499	Checking access to requested template	warning	debug		2006-09-10 23:42:50.708965
2500	Access granted, forwarding user to dpshome.tpl	warning	debug		2006-09-10 23:42:50.723765
2501	Exception: 	warning	MVC	Error Code: 0\nFile: /var/www/toolkit/MVC/MVCUtils.class.php\nLine: 107\nStack Trace:\n#0 /var/www/toolkit/MVC/MVCUtils.class.php(74): MVCUtils::includeClass('DPSUpdateCartMo...', 'DPS', 'models')\n#1 /var/www/toolkit/MVC/MVCUtils.class.php(208): MVCUtils::includeModel('DPSUpdateCartMo...', 'DPS')\n#2 /var/www/toolkit/MVC/Page.class.php(204): MVCUtils::initializeModel(Array, 'dpsCartEditForm', 'DPS', 'DPS', Array, Array)\n#3 /var/www/toolkit/index.php(12): Page->__construct()\n#4 {main}\n	2006-09-11 00:10:52.348544
2502	Checking access to requested template	warning	debug		2006-09-11 00:37:18.726861
2503	Access granted, forwarding user to dpshome.tpl	warning	debug		2006-09-11 00:37:18.741642
2504	Checking access to requested template	warning	debug		2006-09-11 00:38:58.475584
2505	Access granted, forwarding user to dpshome.tpl	warning	debug		2006-09-11 00:38:58.49643
2506	Checking access to requested template	warning	debug		2006-09-11 22:52:31.731925
2507	Access granted, forwarding user to dpshome.tpl	warning	debug		2006-09-11 22:52:31.786302
2508	Checking access to requested template	warning	debug		2006-09-12 00:53:49.928152
2509	Access granted, forwarding user to dpshome.tpl	warning	debug		2006-09-12 00:53:49.942969
2510	Checking access to requested template	warning	debug		2006-09-12 02:58:04.108981
2511	Access granted, forwarding user to dpshome.tpl	warning	debug		2006-09-12 02:58:04.12225
2512	Checking access to requested template	warning	debug		2006-09-12 14:42:51.780098
2513	Access granted, forwarding user to dpshome.tpl	warning	debug		2006-09-12 14:42:51.79522
2514	Checking access to requested template	warning	debug		2006-09-12 16:06:00.31726
2515	Access granted, forwarding user to dpshome.tpl	warning	debug		2006-09-12 16:06:00.328803
2516	Checking access to requested template	warning	debug		2006-09-12 16:51:14.73036
2517	Access granted, forwarding user to dpshome.tpl	warning	debug		2006-09-12 16:51:14.744916
2518	Checking access to requested template	warning	debug		2006-09-12 20:26:26.468326
2519	Access granted, forwarding user to dpshome.tpl	warning	debug		2006-09-12 20:26:26.481717
2520	Checking access to requested template	warning	debug		2006-09-12 21:33:07.97089
2521	Access granted, forwarding user to dpshome.tpl	warning	debug		2006-09-12 21:33:07.986577
2522	Exception: 	warning	MVC	Error Code: 0\nFile: /var/www/toolkit/MVC/MVCUtils.class.php\nLine: 107\nStack Trace:\n#0 /var/www/toolkit/MVC/MVCUtils.class.php(74): MVCUtils::includeClass('dpsAddCartwallP...', 'DPS', 'models')\n#1 /var/www/toolkit/MVC/MVCUtils.class.php(208): MVCUtils::includeModel('dpsAddCartwallP...', 'DPS')\n#2 /var/www/toolkit/MVC/Page.class.php(204): MVCUtils::initializeModel(Array, 'dpsAddCartwallP...', 'DPS', 'DPS', Array, Array)\n#3 /var/www/toolkit/index.php(12): Page->__construct()\n#4 {main}\n	2006-09-12 21:41:49.222524
2523	Checking access to requested template	warning	debug		2006-09-13 00:45:36.638284
2524	Access granted, forwarding user to dpshome.tpl	warning	debug		2006-09-13 00:45:36.65263
2525	Checking access to requested template	warning	debug		2006-09-13 00:57:43.530046
2526	Access granted, forwarding user to dpshome.tpl	warning	debug		2006-09-13 00:57:43.545596
2527	Checking access to requested template	warning	debug		2006-09-13 22:27:30.029628
2528	Access granted, forwarding user to dpshome.tpl	warning	debug		2006-09-13 22:27:30.042747
2529	Checking access to requested template	warning	debug		2006-09-13 23:01:55.382174
2530	Access granted, forwarding user to dpshome.tpl	warning	debug		2006-09-13 23:01:55.397357
2531	Checking access to requested template	warning	debug		2006-09-14 00:50:02.047132
2532	Access granted, forwarding user to dpshome.tpl	warning	debug		2006-09-14 00:50:02.062104
2533	Checking access to requested template	warning	debug		2006-09-14 00:51:43.09709
2534	Access granted, forwarding user to dpshome.tpl	warning	debug		2006-09-14 00:51:43.112003
2535	Checking access to requested template	warning	debug		2006-09-14 01:36:00.526699
2536	Access granted, forwarding user to dpshome.tpl	warning	debug		2006-09-14 01:36:00.538425
2537	Checking access to requested template	warning	debug		2006-09-14 01:45:26.663969
2538	Access granted, forwarding user to dpshome.tpl	warning	debug		2006-09-14 01:45:26.677545
2539	Checking access to requested template	warning	debug		2006-09-14 01:47:38.310885
2540	Access granted, forwarding user to dpshome.tpl	warning	debug		2006-09-14 01:47:38.325061
2541	Checking access to requested template	warning	debug		2006-09-14 01:50:37.87471
2542	Access granted, forwarding user to dpshome.tpl	warning	debug		2006-09-14 01:50:37.888068
2543	Checking access to requested template	warning	debug		2006-09-14 02:00:17.348333
2544	Access granted, forwarding user to dpshome.tpl	warning	debug		2006-09-14 02:00:17.366156
2545	Checking access to requested template	warning	debug		2006-09-14 02:16:07.008625
2546	Access granted, forwarding user to dpshome.tpl	warning	debug		2006-09-14 02:16:07.023418
2547	Checking access to requested template	warning	debug		2006-09-14 14:11:42.779205
2548	Access granted, forwarding user to dpshome.tpl	warning	debug		2006-09-14 14:11:42.873386
2549	Checking access to requested template	warning	debug		2006-09-14 15:12:27.436511
2550	Access granted, forwarding user to dpshome.tpl	warning	debug		2006-09-14 15:12:27.470952
2551	Exception: 	warning	MVC	Error Code: 0\nFile: /var/www/toolkit/MVC/MVCUtils.class.php\nLine: 107\nStack Trace:\n#0 /var/www/toolkit/MVC/MVCUtils.class.php(69): MVCUtils::includeClass('LogoutViewer', 'DPS', 'viewers')\n#1 /var/www/toolkit/MVC/MVCUtils.class.php(240): MVCUtils::includeViewer('LogoutViewer', 'DPS')\n#2 /var/www/toolkit/tkfecommon/models/Model.class.php(90): MVCUtils::initializeViewer(Array, NULL, 'DPS', Array, Array)\n#3 /var/www/toolkit/MVC/MVCUtils.class.php(217) : eval()'d code(1): Model->__construct(Array, NULL, 'MVC', 'DPS', Array, Array)\n#4 /var/www/toolkit/MVC/MVCUtils.class.php(217): eval()\n#5 /var/www/toolkit/MVC/Page.class.php(204): MVCUtils::initializeModel(Array, NULL, 'MVC', 'DPS', Array, Array)\n#6 /var/www/toolkit/index.php(12): Page->__construct()\n#7 {main}\n	2006-09-14 15:20:11.188008
2552	Exception: 	warning	MVC	Error Code: 0\nFile: /var/www/toolkit/MVC/MVCUtils.class.php\nLine: 114\nStack Trace:\n#0 /var/www/toolkit/MVC/MVCUtils.class.php(69): MVCUtils::includeClass('LogoutViewer', 'DPS', 'viewers')\n#1 /var/www/toolkit/MVC/MVCUtils.class.php(240): MVCUtils::includeViewer('LogoutViewer', 'DPS')\n#2 /var/www/toolkit/tkfecommon/models/Model.class.php(90): MVCUtils::initializeViewer(Array, NULL, 'DPS', Array, Array)\n#3 /var/www/toolkit/MVC/MVCUtils.class.php(217) : eval()'d code(1): Model->__construct(Array, NULL, 'MVC', 'DPS', Array, Array)\n#4 /var/www/toolkit/MVC/MVCUtils.class.php(217): eval()\n#5 /var/www/toolkit/MVC/Page.class.php(204): MVCUtils::initializeModel(Array, NULL, 'MVC', 'DPS', Array, Array)\n#6 /var/www/toolkit/index.php(12): Page->__construct()\n#7 {main}\n	2006-09-14 15:21:25.120809
2553	Checking access to requested template	warning	debug		2006-09-14 15:23:02.526994
2554	Access granted, forwarding user to dpshome.tpl	warning	debug		2006-09-14 15:23:02.539593
2555	Checking access to requested template	warning	debug		2006-09-15 21:59:04.809425
2556	Access granted, forwarding user to dpshome.tpl	warning	debug		2006-09-15 21:59:04.834558
2557	Checking access to requested template	warning	debug		2006-09-15 22:00:35.800467
2558	Access granted, forwarding user to dpshome.tpl	warning	debug		2006-09-15 22:00:35.81331
2559	Checking access to requested template	warning	debug		2006-09-16 10:43:43.526684
2560	Access granted, forwarding user to dpshome.tpl	warning	debug		2006-09-16 10:43:43.541376
2561	Checking access to requested template	warning	debug		2006-09-19 16:06:53.063233
2562	Access granted, forwarding user to dpshome.tpl	warning	debug		2006-09-19 16:06:53.080017
2563	Exception: 	warning	unspecified	Error Code: 0\nFile: /var/www/toolkit/MVC/Page.class.php\nLine: 307\nStack Trace:\n#0 /var/www/toolkit/MVC/Page.class.php(109): Page->loadFieldData()\n#1 /var/www/toolkit/index.php(12): Page->__construct()\n#2 {main}\n	2006-09-19 16:58:27.408533
2564	No Module or function name defined, please\n\t\t\tuse the format {use func="<ModuleName>::<FunctionName>"\n\t\t\tparamlist..}	warning	unspecified		2006-09-19 18:07:57.052297
2565	No Module or function name defined, please\n\t\t\tuse the format {use func="<ModuleName>::<FunctionName>"\n\t\t\tparamlist..}	warning	unspecified		2006-09-19 18:08:14.831259
2566	No Module or function name defined, please\n\t\t\tuse the format {use func="<ModuleName>::<FunctionName>"\n\t\t\tparamlist..}	warning	unspecified		2006-09-19 18:08:17.309266
2567	Exception: 	warning	MVC	Error Code: 0\nFile: /var/www/toolkit/MVC/MVCUtils.class.php\nLine: 107\nStack Trace:\n#0 /var/www/toolkit/MVC/MVCUtils.class.php(74): MVCUtils::includeClass('DPSUpdateCartwa...', 'DPS', 'models')\n#1 /var/www/toolkit/MVC/MVCUtils.class.php(208): MVCUtils::includeModel('DPSUpdateCartwa...', 'DPS')\n#2 /var/www/toolkit/MVC/Page.class.php(204): MVCUtils::initializeModel(Array, 'dpsCartwallEdit...', 'DPS', 'DPS', Array, Array)\n#3 /var/www/toolkit/index.php(12): Page->__construct()\n#4 {main}\n	2006-09-20 15:22:49.219047
2568	Checking access to requested template	warning	debug		2006-09-20 23:42:46.378273
2569	Access granted, forwarding user to dpshome.tpl	warning	debug		2006-09-20 23:42:46.390794
2570	Checking access to requested template	warning	debug		2006-09-21 08:35:03.294593
2571	Access granted, forwarding user to dpshome.tpl	warning	debug		2006-09-21 08:35:03.307355
2572	Checking access to requested template	warning	debug		2006-09-21 16:14:58.769418
2573	Access granted, forwarding user to dpshome.tpl	warning	debug		2006-09-21 16:14:58.78127
2574	Checking access to requested template	warning	debug		2006-09-21 16:15:27.774791
2575	Access granted, forwarding user to dpshome.tpl	warning	debug		2006-09-21 16:15:27.787177
2576	Checking access to requested template	warning	debug		2006-09-21 16:25:09.106026
2577	Access granted, forwarding user to dpshome.tpl	warning	debug		2006-09-21 16:25:09.117519
2578	Checking access to requested template	warning	debug		2006-09-21 16:25:47.143655
2579	Access granted, forwarding user to dpshome.tpl	warning	debug		2006-09-21 16:25:47.160063
2580	Checking access to requested template	warning	debug		2006-09-21 16:26:01.53829
2581	Access granted, forwarding user to dpshome.tpl	warning	debug		2006-09-21 16:26:01.551299
2582	Checking access to requested template	warning	debug		2006-09-21 20:58:50.631645
2583	Access granted, forwarding user to dpshome.tpl	warning	debug		2006-09-21 20:58:50.645703
2584	Checking access to requested template	warning	debug		2006-09-21 21:59:17.614863
2585	Access granted, forwarding user to dpshome.tpl	warning	debug		2006-09-21 21:59:17.629551
2586	Exception: 	warning	MVC	Error Code: 0\nFile: /var/www/toolkit/MVC/MVCUtils.class.php\nLine: 114\nStack Trace:\n#0 /var/www/toolkit/MVC/MVCUtils.class.php(79): MVCUtils::includeClass('DPSUserCartsetR...', 'DPS', 'validators/fiel...')\n#1 /var/www/toolkit/tkfecommon/validators/form/FormValidator.class.php(49): MVCUtils::includeValidator('DPSUserCartsetR...', 'DPS')\n#2 /var/www/toolkit/MVC/Page.class.php(359): FormValidator->isValid()\n#3 /var/www/toolkit/MVC/Page.class.php(196): Page->validate()\n#4 /var/www/toolkit/index.php(12): Page->__construct()\n#5 {main}\n	2006-09-21 22:27:06.215186
2587	Checking access to requested template	warning	debug		2006-09-21 22:59:22.300917
2588	Access granted, forwarding user to dpshome.tpl	warning	debug		2006-09-21 22:59:22.313045
2589	Checking access to requested template	warning	debug		2006-09-22 13:25:39.013229
2590	Access granted, forwarding user to dpshome.tpl	warning	debug		2006-09-22 13:25:39.026865
2591	Checking access to requested template	warning	debug		2006-09-22 14:39:29.053977
2592	Access granted, forwarding user to dpshome.tpl	warning	debug		2006-09-22 14:39:29.068079
2593	Checking access to requested template	warning	debug		2006-09-22 15:42:02.461817
2594	Access granted, forwarding user to dpshome.tpl	warning	debug		2006-09-22 15:42:02.47612
2595	Checking access to requested template	warning	debug		2006-09-22 17:30:51.349767
2596	Access granted, forwarding user to dpshome.tpl	warning	debug		2006-09-22 17:30:51.364991
2597	Checking access to requested template	warning	debug		2006-09-22 18:48:30.525291
2598	Access granted, forwarding user to dpshome.tpl	warning	debug		2006-09-22 18:48:30.560983
2599	Checking access to requested template	warning	debug		2006-09-25 11:42:19.820602
2600	Access granted, forwarding user to dpshome.tpl	warning	debug		2006-09-25 11:42:19.840237
2601	Checking access to requested template	warning	debug		2006-09-25 11:49:46.367526
2602	Access granted, forwarding user to dpshome.tpl	warning	debug		2006-09-25 11:49:46.379728
2603	Checking access to requested template	warning	debug		2006-09-25 11:50:23.570565
2604	Access granted, forwarding user to dpshome.tpl	warning	debug		2006-09-25 11:50:23.583312
2605	Exception: 	warning	MVC	Error Code: 0\nFile: /var/www/toolkit/MVC/MVCUtils.class.php\nLine: 107\nStack Trace:\n#0 /var/www/toolkit/MVC/MVCUtils.class.php(69): MVCUtils::includeClass('DPSShowFrontVie...', 'DPS', 'viewers')\n#1 /var/www/toolkit/MVC/MVCUtils.class.php(240): MVCUtils::includeViewer('DPSShowFrontVie...', 'DPS')\n#2 /var/www/toolkit/tkfecommon/models/Model.class.php(90): MVCUtils::initializeViewer(Array, NULL, 'DPS', Array, Array)\n#3 /var/www/toolkit/MVC/MVCUtils.class.php(217) : eval()'d code(1): Model->__construct(Array, NULL, 'MVC', 'DPS', Array, Array)\n#4 /var/www/toolkit/MVC/MVCUtils.class.php(217): eval()\n#5 /var/www/toolkit/MVC/Page.class.php(204): MVCUtils::initializeModel(Array, NULL, 'MVC', 'DPS', Array, Array)\n#6 /var/www/toolkit/index.php(12): Page->__construct()\n#7 {main}\n	2006-09-25 12:34:16.906231
\.


--
-- PostgreSQL database dump complete
--

--
-- PostgreSQL database dump
--

SET client_encoding = 'UTF8';
SET check_function_bodies = false;
SET client_min_messages = warning;

SET search_path = public, pg_catalog;

--
-- Data for Name: realmgrouplink; Type: TABLE DATA; Schema: public; Owner: www-data
--

COPY realmgrouplink (groupid, realmid, allow) FROM stdin;
2	59	y
2	60	y
2	56	y
2	55	y
3	1	y
1	72	y
3	58	y
3	8	y
\.


--
-- PostgreSQL database dump complete
--

--
-- PostgreSQL database dump
--

SET client_encoding = 'UTF8';
SET check_function_bodies = false;
SET client_min_messages = warning;

SET search_path = public, pg_catalog;

--
-- Name: realms_realmid_seq; Type: SEQUENCE SET; Schema: public; Owner: www-data
--

SELECT pg_catalog.setval(pg_catalog.pg_get_serial_sequence('realms', 'realmid'), 76, true);


--
-- Data for Name: realms; Type: TABLE DATA; Schema: public; Owner: www-data
--

COPY realms (realmid, name, parentid, description, depth, realmpath) FROM stdin;
1	Administration	0	Realm Administration	0	01
8	Site	0	Public website	0	08
19	Authentication	1	Authentication configuration	1	01.19
20	Users	19	User Administration	2	01.19.20
21	Groups	19	Group Administration	2	01.19.21
22	Realms	19	Realm Administration	2	01.19.22
23	Add	20		3	01.19.20.23
24	Modify	20		3	01.19.20.24
25	Delete	20		3	01.19.20.25
26	Add	22		3	01.19.22.26
27	Modify	22		3	01.19.22.27
28	Delete	22		3	01.19.22.28
29	Add	21		3	01.19.21.29
30	Modify	21		3	01.19.21.30
31	Delete	21		3	01.19.21.31
32	Templates	1		1	01.32
55	Public Site	8	Public Site for Visitors	1	08.55
56	Private Site	8	Viewable pages for all other users	1	08.56
58	DPS	0	DPS Root realm	0	58
61	Edit Track	59	DPS Edit Track	2	58.59.61
62	Search Track	59	DPS Search Track	2	58.59.62
63	Request Track	59	DPS Request Track	2	58.59.63
64	Report Track	59	DPS Report Track	2	58.59.64
65	Censor Track	59	DPS Censor Track	2	58.59.65
66	Edit Sue Playlist	60	DPS Edit Sue Track	2	58.60.66
67	Remove Track Request	59	DPS Remove a track request	2	58.59.67
60	Sue	58	DPS Root Sue	1	58.60
59	Music Library	58	DPS Root Music Library	1	58.59
68	Delete Track	59	Delete a track from the system	2	58.59.68
69	Studio	58	Alter Studio Stuff	1	58.69
70	Studio Cartwall	69	Alter Studio Cartwall	2	58.69.70
72	CMS	58	CMS Regions	1	58.72
71	Edit Help	72	Edit the Help pages	2	58.72.71
73	Edit Music	71	Edit the Music page	2	58.72.73
74	Edit Sue	71	Edit the Sue page	2	58.72.74
75	Edit Studio	71	Edit the Studio page	2	58.72.75
76	Edit Show	71	Edit the Show page	2	58.72.75
\.


--
-- PostgreSQL database dump complete
--

--
-- PostgreSQL database dump
--

SET client_encoding = 'UTF8';
SET check_function_bodies = false;
SET client_min_messages = warning;

SET search_path = public, pg_catalog;

--
-- Name: realmuserlink_userid_seq; Type: SEQUENCE SET; Schema: public; Owner: www-data
--

SELECT pg_catalog.setval(pg_catalog.pg_get_serial_sequence('realmuserlink', 'userid'), 1, false);


--
-- Data for Name: realmuserlink; Type: TABLE DATA; Schema: public; Owner: www-data
--

COPY realmuserlink (userid, realmid, allow) FROM stdin;
-1	55	y
\.


--
-- PostgreSQL database dump complete
--

--
-- PostgreSQL database dump
--

SET client_encoding = 'UTF8';
SET check_function_bodies = false;
SET client_min_messages = warning;

SET search_path = public, pg_catalog;

--
-- Name: sessions_sessionid_seq; Type: SEQUENCE SET; Schema: public; Owner: www-data
--

SELECT pg_catalog.setval(pg_catalog.pg_get_serial_sequence('sessions', 'sessionid'), 1, false);


--
-- Data for Name: sessions; Type: TABLE DATA; Schema: public; Owner: www-data
--

COPY sessions (sessionid, useragent, ip, rndidentifier, lastaccess) FROM stdin;
509	Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.8.0.7) Gecko/20060909 Firefox/1.5.0.7	192.168.1.1	4B6QwT6m4T680M	1158770927
454	Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.8.0.6) Gecko/20060728 Firefox/1.5.0.6	192.168.1.1	yyw6K0kGm9224Y	1156828789
510	Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.8.0.7) Gecko/20060909 Firefox/1.5.0.7	192.168.1.1	poLB01Vgp9477J	1158788024
455	Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.8.0.6) Gecko/20060728 Firefox/1.5.0.6	192.168.1.1	NU1g6BUe0CkJ6Q	1157131335
511	Mozilla/5.0 (X11; U; Linux i686; en-GB; rv:1.8.0.5) Gecko/20060731 Ubuntu/dapper-security Firefox/1.5.0.5	192.168.1.1	p91yRrkwowpseN	1158790516
478	Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.8.0.6) Gecko/20060728 Firefox/1.5.0.6	192.168.1.1	G28I61wlmaKsIo	1158076266
456	Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.8.0.6) Gecko/20060728 Firefox/1.5.0.6	192.168.1.1	B9fw4hl5HP7PF5	1157304615
457	Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.8.0.6) Gecko/20060728 Firefox/1.5.0.6	192.168.1.1	EefssymLGJWX2D	1157309037
458	Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.8.0.6) Gecko/20060728 Firefox/1.5.0.6	192.168.1.1	q8FVae35o8N6bH	1157749159
459	Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.8.0.6) Gecko/20060728 Firefox/1.5.0.6	192.168.1.1	6H5pC1L01s8ENu	1157901786
512	Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.8.0.7) Gecko/20060909 Firefox/1.5.0.7	192.168.1.1	YbVw7mf40EL9pY	1158791760
479	Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.8.0.6) Gecko/20060728 Firefox/1.5.0.6	192.168.1.1	6VqDGU74E5LgJn	1158089182
482	Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.8.0.6) Gecko/20060728 Firefox/1.5.0.6	192.168.1.1	v64eeoATmDW943	1158182840
513	Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 5.2; WOW64; .NET CLR 2.0.50727)	192.168.1.1	v2Vs82xNt8z20T	1158824094
514	Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.8.0.7) Gecko/20060909 Firefox/1.5.0.7	192.168.1.1	aIy81bxq06An82	1158847022
460	Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.8.0.6) Gecko/20060728 Firefox/1.5.0.6	192.168.1.1	1LS68K54G4iNkZ	1157906190
515	Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.8.0.7) Gecko/20060909 Firefox/1.5.0.7	192.168.1.1	0X19OjI7erhhiS	1158851692
516	Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1; (R1 1.5); .NET CLR 1.1.4322; .NET CLR 2.0.50727)	192.168.1.1	1KoSIkoh1DplTQ	1158851716
461	Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.8.0.6) Gecko/20060728 Firefox/1.5.0.6	192.168.1.1	19YTu4GIKjz1Tg	1157909947
481	Mozilla/5.0 (X11; U; Linux i686; en-GB; rv:1.8.0.5) Gecko/20060731 Ubuntu/dapper-security Firefox/1.5.0.5	192.168.1.1	rJ13LNEoFz8mIG	1158105459
483	Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.8.0.6) Gecko/20060728 Firefox/1.5.0.6	192.168.1.1	j45DRcMPX1908c	1158184909
517	Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.8.0.7) Gecko/20060909 Firefox/1.5.0.7	192.168.1.1	og5H8QXLraX308	1158868726
480	Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.8.0.6) Gecko/20060728 Firefox/1.5.0.6	192.168.1.1	iYW0c0w9U5BVbt	1158104732
462	Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.8.0.6) Gecko/20060728 Firefox/1.5.0.6	192.168.1.1	MS34dE9222x18s	1157913805
463	Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.8.0.6) Gecko/20060728 Firefox/1.5.0.6	192.168.1.1	p3320SN4dVB7N8	1157917407
484	Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.8.0.6) Gecko/20060728 Firefox/1.5.0.6	192.168.1.1	14kt4Mf3YAcTGh	1158184910
464	Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.8.0.6) Gecko/20060728 Firefox/1.5.0.6	192.168.1.1	Fe43wx8o7ByQCS	1157921388
466	Mozilla/5.0 (X11; U; Linux i686; en-GB; rv:1.8.0.5) Gecko/20060731 Ubuntu/dapper-security Firefox/1.5.0.5	192.168.1.1	PDZQHVVjo7ajKF	1157926822
465	Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.8.0.6) Gecko/20060728 Firefox/1.5.0.6	192.168.1.1	248p1Q2Vs37cs0	1157925776
485	Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.0)	192.168.1.1	0s2DxmX4DggurG	1158190524
486	Mozilla/5.0 (X11; U; Linux i686; en-GB; rv:1.8.0.5) Gecko/20060731 Ubuntu/dapper-security Firefox/1.5.0.5	192.168.1.1	JJKC8c3Xb7AmUD	1158191397
518	Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.8.0.7) Gecko/20060909 Firefox/1.5.0.7	192.168.1.1	CO1v9xQA6n8i1l	1158872351
468	Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.8.0.6) Gecko/20060728 Firefox/1.5.0.6	192.168.1.1	10cmw7SA5049d7	1157929272
469	Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.8.0.6) Gecko/20060728 Firefox/1.5.0.6	192.168.1.1	LlyWfucptHVyxN	1157929280
470	Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.8.0.6) Gecko/20060728 Firefox/1.5.0.6	192.168.1.1	DF7kSNZzSP1cVQ	1157929294
471	Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.8.0.6) Gecko/20060728 Firefox/1.5.0.6	192.168.1.1	OrTU6ma2UGH4M7	1157929306
487	Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1; .NET CLR 1.1.4322)	192.168.1.1	9zH1GnZ9N74i60	1158191548
519	Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.8.0.7) Gecko/20060909 Firefox/1.5.0.7	192.168.1.1	bF4f85mM86m060	1158875958
467	Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.8.0.6) Gecko/20060728 Firefox/1.5.0.6	192.168.1.1	dD4E8jIuvg4g6x	1157927818
473	Mozilla/5.0 (X11; U; Linux i686; en-GB; rv:1.8.0.5) Gecko/20060731 Ubuntu/dapper-security Firefox/1.5.0.5	192.168.1.1	wI8DEZnoyRIy4H	1157931534
472	Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.8.0.6) Gecko/20060728 Firefox/1.5.0.6	192.168.1.1	QM5P9jdcVbo9b9	1157931434
488	Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.8.0.6) Gecko/20060728 Firefox/1.5.0.6	192.168.1.1	74o3O2Z33Xk73u	1158194157
520	Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.8.0.7) Gecko/20060909 Firefox/1.5.0.7	192.168.1.1	bi75mNvq77NiSn	1158927934
490	Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.8.0.6) Gecko/20060728 Firefox/1.5.0.6	192.168.1.1	D6gDi5L6DA87n3	1158195037
474	Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.8.0.6) Gecko/20060728 Firefox/1.5.0.6	192.168.1.1	IY9OKIz4bDUxZt	1158011546
491	Mozilla/5.0 (X11; U; Linux i686; en-US; rv:1.7.10) Gecko/20060804 Firefox/1.0.4 (Debian package 1.0.4-2sarge10)	192.168.1.1	0347Vr8weZ50lZ	1158195604
521	Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.8.0.7) Gecko/20060909 Firefox/1.5.0.7	192.168.1.1	aUPt4QcI74cfc7	1158932357
522	Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.8.0.7) Gecko/20060909 Firefox/1.5.0.7	192.168.1.1	2c25JhCs1dD92q	1158936118
489	Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1; (R1 1.5); .NET CLR 1.1.4322; .NET CLR 2.0.50727)	192.168.1.1	h4eSv298Z1vp0L	1158195027
523	Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.8.0.7) Gecko/20060909 Firefox/1.5.0.7	192.168.1.1	s6bkg619941kgl	1158942649
475	Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.8.0.6) Gecko/20060728 Firefox/1.5.0.6	192.168.1.1	r04z3jZJ6uI9bG	1158018826
524	Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.8.0.7) Gecko/20060909 Firefox/1.5.0.7	192.168.1.1	8c4yvog0715961	1158947307
525	Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.8.0.4) Gecko/20060508 Firefox/1.5.0.4	192.168.1.1	G7P5B5Md88nYbB	1159180904
526	Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.8.0.7) Gecko/20060909 Firefox/1.5.0.7	192.168.1.1	KBnz5t4LtUvciY	1159181334
476	Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.8.0.6) Gecko/20060728 Firefox/1.5.0.6	192.168.1.1	eW0m6k50Z2R9vR	1158026275
527	Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.8.0.4) Gecko/20060508 Firefox/1.5.0.4	192.168.1.1	1j6lbXDjokJk7O	1159181417
477	Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.8.0.6) Gecko/20060728 Firefox/1.5.0.6	192.168.1.1	ubdd4EcaCl3CYl	1158068567
492	Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.8.0.6) Gecko/20060728 Firefox/1.5.0.6	192.168.1.1	ST1m3PP4R0CWPM	1158239499
493	Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.8.0.6) Gecko/20060728 Firefox/1.5.0.6	192.168.1.1	jQgWUgEJM25X6f	1158243136
494	Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.7.12) Gecko/20050919 Firefox/1.0.7	192.168.1.1	jSy41mYPpE4YQX	1158353931
495	Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.7.12) Gecko/20050919 Firefox/1.0.7	192.168.1.1	HfgrV7v0bwx103	1158354026
496	Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.7.12) Gecko/20050919 Firefox/1.0.7	192.168.1.1	kIR2WQ9nrssw57	1158399819
497	Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.8.0.7) Gecko/20060909 Firefox/1.5.0.7	192.168.1.1	XCN87uOpn1ggt7	1158678397
498	Mozilla/5.0 (X11; U; Linux i686; en-GB; rv:1.8.0.5) Gecko/20060731 Ubuntu/dapper-security Firefox/1.5.0.5	192.168.1.1	ACFazC98tLQwGd	1158681717
499	Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1; .NET CLR 1.1.4322)	192.168.1.1	tIRq1cap9jL44v	1158681813
501	Mozilla/5.0 (X11; U; Linux i686; en-US; rv:1.8.0.6) Gecko/20060728 Firefox/1.5.0.6 (Debian-1.5.dfsg+1.5.0.6-4)	192.168.1.1	Jsoa5Fj66NmP76	1158683344
500	Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1; .NET CLR 1.1.4322)	192.168.1.1	f9XaAsM1369k7C	1158682695
502	Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.8.0.7) Gecko/20060909 Firefox/1.5.0.7	192.168.1.1	hw26p7h9eU5257	1158685614
503	Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.8.0.7) Gecko/20060909 Firefox/1.5.0.7	192.168.1.1	w1B38lns8z89Hc	1158689225
504	Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.8.0.7) Gecko/20060909 Firefox/1.5.0.7	192.168.1.1	5oul2agqD80M33	1158691957
505	Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.8.0.7) Gecko/20060909 Firefox/1.5.0.7	192.168.1.1	VnFbGB953Zp7af	1158694816
506	Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.8.0.7) Gecko/20060909 Firefox/1.5.0.7	192.168.1.1	RwjH8iRL6ZjUWW	1158758630
507	Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.8.0.7) Gecko/20060909 Firefox/1.5.0.7	192.168.1.1	G0Hk99d21ELXix	1158762234
508	Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.8.0.7) Gecko/20060909 Firefox/1.5.0.7	192.168.1.1	qMeB3UYqvHvDT3	1158766771
\.


--
-- PostgreSQL database dump complete
--

--
-- PostgreSQL database dump
--

SET client_encoding = 'UTF8';
SET check_function_bodies = false;
SET client_min_messages = warning;

SET search_path = public, pg_catalog;

--
-- Name: sessionvalues_valueid_seq; Type: SEQUENCE SET; Schema: public; Owner: www-data
--

SELECT pg_catalog.setval(pg_catalog.pg_get_serial_sequence('sessionvalues', 'valueid'), 1, false);


--
-- Data for Name: sessionvalues; Type: TABLE DATA; Schema: public; Owner: www-data
--

COPY sessionvalues (valueid, sessionid, skey, svalue) FROM stdin;
3012	421	auth_user	visitor
3013	421	auth_lastRequestTime	1153623993
3014	422	auth_user	visitor
3015	422	auth_lastRequestTime	1153623995
3018	423	auth_user	psharpe
3020	423	auth_lastRequestTime	1153623995
3193	429	auth_user	psharpe
3021	424	auth_user	visitor
3022	424	auth_lastRequestTime	1153623995
2877	398	auth_user	psharpe
2879	398	auth_lastRequestTime	1153302114
3086	425	auth_lastRequestTime	1153682980
3222	430	auth_lastRequestTime	1153688788
2880	399	auth_user	visitor
2881	399	auth_lastRequestTime	1153302114
3026	425	auth_user	psharpe
2882	400	auth_user	visitor
2883	400	auth_lastRequestTime	1153302183
3139	426	auth_lastRequestTime	1153683890
3199	429	auth_lastRequestTime	1153688039
2884	401	auth_user	visitor
2885	401	auth_lastRequestTime	1153302218
2888	402	auth_user	psharpe
2890	402	auth_lastRequestTime	1153302233
3092	426	auth_user	psharpe
2891	403	auth_user	visitor
2892	403	auth_lastRequestTime	1153302233
2895	404	auth_user	psharpe
2897	404	auth_lastRequestTime	1153302263
2986	412	auth_lastRequestTime	1153527770
3145	427	auth_user	psharpe
2898	405	auth_user	visitor
2899	405	auth_lastRequestTime	1153302263
2987	413	auth_user	visitor
2988	413	auth_lastRequestTime	1153608506
3176	428	auth_lastRequestTime	1153684714
3206	430	auth_user	psharpe
2902	406	auth_user	psharpe
2904	406	auth_lastRequestTime	1153302273
2989	414	auth_user	visitor
2990	414	auth_lastRequestTime	1153608508
3149	427	auth_lastRequestTime	1153684308
2905	407	auth_user	visitor
2906	407	auth_lastRequestTime	1153302273
2993	415	auth_user	cbemment
2995	415	auth_lastRequestTime	1153608520
2909	408	auth_user	psharpe
2911	408	auth_lastRequestTime	1153302283
2996	416	auth_user	visitor
2997	416	auth_lastRequestTime	1153623988
2912	409	auth_user	visitor
2913	409	auth_lastRequestTime	1153302283
3000	417	auth_user	psharpe
3002	417	auth_lastRequestTime	1153623991
3154	428	auth_user	psharpe
2914	410	auth_user	visitor
2915	410	auth_lastRequestTime	1153302294
3003	418	auth_user	visitor
3004	418	auth_lastRequestTime	1153623991
2916	411	auth_user	visitor
2917	411	auth_lastRequestTime	1153302335
3005	419	auth_user	visitor
3006	419	auth_lastRequestTime	1153623992
2920	412	auth_user	psharpe
3009	420	auth_user	psharpe
3011	420	auth_lastRequestTime	1153623993
3223	431	auth_user	visitor
3224	431	auth_lastRequestTime	1155240044
3225	432	auth_user	visitor
3226	432	auth_lastRequestTime	1155240045
3229	433	auth_user	psharpe
3231	433	auth_lastRequestTime	1155240057
3232	434	auth_user	visitor
3233	434	auth_lastRequestTime	1155240058
3238	435	auth_user	psharpe
3241	435	auth_lastRequestTime	1155319226
3247	436	auth_user	psharpe
3254	436	auth_lastRequestTime	1155322577
3259	437	auth_user	psharpe
3269	437	auth_lastRequestTime	1156106978
3275	438	auth_user	psharpe
3282	438	auth_lastRequestTime	1156107034
3288	439	auth_user	psharpe
3293	439	auth_lastRequestTime	1156107081
3294	440	auth_user	visitor
3295	440	auth_lastRequestTime	1156107124
3300	441	auth_user	psharpe
3306	441	auth_lastRequestTime	1156111137
3311	442	auth_user	psharpe
3354	442	auth_lastRequestTime	1156539967
3359	443	auth_user	psharpe
3364	443	auth_lastRequestTime	1156540696
3369	444	auth_user	psharpe
3374	444	auth_lastRequestTime	1156540736
3402	445	auth_user	psharpe
3411	445	auth_lastRequestTime	1156786167
3416	446	auth_user	psharpe
3459	446	auth_lastRequestTime	1156790470
3464	447	auth_user	psharpe
3476	447	auth_lastRequestTime	1156791786
3488	448	auth_user	ccantwell
3503	448	auth_lastRequestTime	1156795880
3508	449	auth_user	psharpe
3549	449	auth_lastRequestTime	1156808991
3555	450	auth_user	psharpe
3575	450	auth_lastRequestTime	1156809189
3580	451	auth_user	psharpe
3587	452	auth_user	visitor
3588	452	auth_lastRequestTime	1156822898
3647	451	auth_lastRequestTime	1156825196
3648	453	auth_user	visitor
6082	498	auth_user	guest
6083	498	auth_lastRequestTime	1158681717
6116	500	auth_user	iliverton
3656	453	auth_lastRequestTime	1156828742
3668	454	auth_user	psharpe
3671	454	auth_lastRequestTime	1156828949
7512	525	auth_lastRequestTime	1159181417
6405	506	auth_user	psharpe
3676	455	auth_user	psharpe
7593	527	auth_lastRequestTime	1159184581
3684	455	auth_lastRequestTime	1157131572
6678	511	auth_user	chawley
3703	456	auth_user	psharpe
6755	512	auth_lastRequestTime	1158792650
7111	520	auth_user	psharpe
5591	486	auth_user	chawley
3762	456	auth_lastRequestTime	1157307280
6315	504	auth_user	guest
6316	504	auth_lastRequestTime	1158692084
4960	477	auth_lastRequestTime	1158075533
7470	524	auth_user	psharpe
3772	457	auth_user	psharpe
6390	505	auth_user	guest
6391	505	auth_lastRequestTime	1158697662
3779	457	auth_lastRequestTime	1157309299
3784	458	auth_user	psharpe
3787	458	auth_lastRequestTime	1157749269
5141	480	auth_user	psharpe
6546	507	auth_lastRequestTime	1158763622
3792	459	auth_user	psharpe
3798	459	auth_lastRequestTime	1157902140
3803	460	auth_user	psharpe
5594	486	auth_lastRequestTime	1158191503
5784	488	auth_lastRequestTime	1158197589
6086	499	auth_user	iliverton
6088	499	auth_lastRequestTime	1158681821
7516	527	auth_user	psharpe
5239	481	auth_user	chawley
3900	460	auth_lastRequestTime	1157909545
3905	461	auth_user	psharpe
6812	513	auth_user	guest
5341	482	auth_user	psharpe
6813	513	auth_lastRequestTime	1158824710
6917	517	auth_lastRequestTime	1158872316
5662	490	auth_user	spain
5664	490	auth_lastRequestTime	1158195043
4806	476	auth_lastRequestTime	1158030812
7356	521	auth_lastRequestTime	1158935040
7440	523	dpsSortType	artist
3973	461	auth_lastRequestTime	1157911562
7493	524	dpsSortType	artist
3978	462	auth_user	psharpe
6549	508	auth_user	psharpe
6648	510	auth_user	psharpe
5323	481	auth_lastRequestTime	1158105966
6814	514	auth_user	guest
4059	462	auth_lastRequestTime	1157917382
6137	500	auth_lastRequestTime	1158684280
4076	463	auth_user	psharpe
4966	478	auth_user	psharpe
7494	524	auth_lastRequestTime	1158947688
6816	514	auth_lastRequestTime	1158848737
4114	463	auth_lastRequestTime	1157920932
4119	464	auth_user	psharpe
7079	518	auth_lastRequestTime	1158875942
5553	484	auth_lastRequestTime	1158187660
5599	487	auth_user	ccantwell
5634	485	auth_user	ccantwell
4145	464	auth_lastRequestTime	1157923905
4150	465	auth_user	psharpe
4167	466	auth_user	chawley
6327	505	CMSShowInLine	n
4187	466	auth_lastRequestTime	1157927027
4189	465	auth_lastRequestTime	1157927817
6744	512	auth_user	psharpe
5336	480	auth_lastRequestTime	1158107980
6924	518	auth_user	psharpe
4231	467	auth_user	psharpe
5678	485	auth_lastRequestTime	1158195358
4246	468	auth_user	guest
4247	468	auth_lastRequestTime	1157929272
4248	469	auth_user	guest
4249	469	auth_lastRequestTime	1157929280
4250	470	auth_user	guest
4251	470	auth_lastRequestTime	1157929294
4252	471	auth_user	guest
4253	471	auth_lastRequestTime	1157929306
6140	502	auth_user	psharpe
7363	522	auth_user	psharpe
6223	502	CMSShowInLine	y
7498	525	auth_user	psharpe
4317	467	auth_lastRequestTime	1157931401
4322	472	auth_user	psharpe
5454	482	auth_lastRequestTime	1158184909
4335	473	auth_user	chawley
5779	489	auth_lastRequestTime	1158197527
4364	473	auth_lastRequestTime	1157931686
4365	472	auth_lastRequestTime	1157931694
4370	474	auth_user	psharpe
6285	503	CMSShowInLine	y
5115	479	auth_user	psharpe
6854	515	auth_user	psharpe
5455	483	auth_user	guest
5457	483	auth_lastRequestTime	1158184909
5604	487	auth_lastRequestTime	1158191568
5682	491	auth_user	ccantwell
5723	488	auth_user	psharpe
4470	474	auth_lastRequestTime	1158018598
4475	475	auth_user	psharpe
6227	502	auth_lastRequestTime	1158689203
7529	527	CMSShowInLine	n
6512	506	auth_lastRequestTime	1158762230
6609	508	auth_lastRequestTime	1158770019
6688	511	auth_lastRequestTime	1158790658
6105	501	auth_user	rboyatt
6107	501	auth_lastRequestTime	1158683346
4907	477	auth_user	psharpe
5135	479	auth_lastRequestTime	1158093784
6827	516	auth_user	psharpe
6858	515	auth_lastRequestTime	1158852501
7161	520	auth_lastRequestTime	1158930093
4663	475	auth_lastRequestTime	1158025769
4669	476	auth_user	psharpe
7386	522	auth_lastRequestTime	1158938980
6290	503	auth_user	guest
6291	503	auth_lastRequestTime	1158691002
5078	478	auth_lastRequestTime	1158080444
6612	509	auth_user	psharpe
6690	510	auth_lastRequestTime	1158790800
6830	516	auth_lastRequestTime	1158851728
5463	484	auth_user	psharpe
5656	489	auth_user	psharpe
5700	491	auth_lastRequestTime	1158195778
5788	492	auth_user	psharpe
6516	507	auth_user	psharpe
6638	509	auth_lastRequestTime	1158772455
6862	517	auth_user	psharpe
5877	492	auth_lastRequestTime	1158243052
5899	493	auth_user	psharpe
7390	523	auth_user	psharpe
5906	493	auth_lastRequestTime	1158243981
5910	494	auth_user	psharpe
7508	526	auth_user	chawley
5923	494	auth_lastRequestTime	1158354026
5929	495	auth_user	psharpe
5956	495	auth_lastRequestTime	1158354143
7106	519	auth_user	guest
7107	519	auth_lastRequestTime	1158877272
5999	496	auth_user	guest
6001	496	auth_lastRequestTime	1158400398
7466	523	auth_lastRequestTime	1158945856
7511	526	auth_lastRequestTime	1159181386
7169	521	auth_user	psharpe
6079	497	auth_user	psharpe
6081	497	auth_lastRequestTime	1158681608
\.


--
-- PostgreSQL database dump complete
--

--
-- PostgreSQL database dump
--

SET client_encoding = 'UTF8';
SET check_function_bodies = false;
SET client_min_messages = warning;

SET search_path = public, pg_catalog;

--
-- Name: templates_templateid_seq; Type: SEQUENCE SET; Schema: public; Owner: www-data
--

SELECT pg_catalog.setval(pg_catalog.pg_get_serial_sequence('templates', 'templateid'), 79, true);


--
-- Data for Name: templates; Type: TABLE DATA; Schema: public; Owner: www-data
--

COPY templates (templateid, filename, viewerclassname, realmid, modulename) FROM stdin;
2	userModify.tpl	UserViewer	1	Auth
3	groupModify.tpl	GroupViewer	1	Auth
4	realmModify.tpl	RealmViewer	1	Auth
8	userAdd.tpl	UserViewer	1	Auth
9	groupAdd.tpl	GroupViewer	1	Auth
10	realmAdd.tpl	RealmViewer	1	Auth
11	listTemplates.tpl	TemplateListViewer	1	MVC
12	addTemplate.tpl	AddTemplateViewer	32	MVC
53	dpstedit.tpl	DPSTrackEditViewer	56	DPS
54	dpstsedit.tpl	DPSTracksEditViewer	56	DPS
55	dpstview.tpl	DPSTracksViewViewer	56	DPS
46	dpslogin.tpl	LoginViewer	55	DPS
47	dpshome.tpl	DPSHomeViewer	56	DPS
56	dpspermissionError.tpl	LoginViewer	55	DPS
20	rPermissionError.tpl	Viewer	55	Auth
26	Rexception.tpl	RenderedExceptionViewer	55	Auth
7	logout.tpl	LogoutViewer	55	Auth
19	newUserInfo.tpl	Viewer	1	CMS
57	dpsgetfile.tpl	DPSMp3PreviewViewer	56	DPS
59	dpstrequest.tpl	DPSTrackRequestViewer	56	DPS
60	dpssstats.tpl	DPSSueStatsViewer	56	DPS
61	dpssplaylist.tpl	DPSSuePlaylistViewer	56	DPS
48	dpsmsearch.tpl	DPSMusicSearchViewer	62	DPS
52	dpstcensor.tpl	DPSTrackCensorViewer	65	DPS
62	dpssaddplaylist.tpl	DPSSueAddPlaylistViewer	66	DPS
71	dpslogout.tpl	LogoutViewer	55	DPS
58	dpshelp.tpl	DPSHelpViewer	56	DPS
13	editContentWindow.tpl	EditContentViewer	55	CMS
14	editContent.tpl	EditContentViewer	55	CMS
15	editContentWindow.rpl	editContentWindowViewer	55	CMS
17	editorForm.tpl	EditorFormViewer	55	CMS
70	dpssteditcartredirect.tpl	Viewer	56	DPS
66	dpsstusercartsets.tpl	DPSUserCartsetsViewer	56	DPS
69	dpssteditcart.tpl	DPSUserEditCartViewer	56	DPS
68	dpssteditcartwall.tpl	DPSUserEditCartsetViewer	56	DPS
67	dpsstviewcartwall.tpl	DPSUserCartwallsViewer	56	DPS
72	dpsststationcartsets.tpl	DPSStationCartsetsViewer	70	DPS
74	dpsststationeditcartwall.tpl	DPSStationEditCartsetViewer	70	DPS
73	dpsststationeditcart.tpl	DPSStationEditCartViewer	70	DPS
75	dpsststationviewcartwall.tpl	DPSStationCartwallsViewer	70	DPS
76	dpsmusicfront.tpl	DPSMusicFrontViewer	56	DPS
77	dpssuefront.tpl	DPSSueFrontViewer	56	DPS
78	dpsstudiofront.tpl	DPSStudioFrontViewer	56	DPS
79	dpsshowfront.tpl	DPSShowFrontViewer	56	DPS
\.


--
-- PostgreSQL database dump complete
--

--
-- PostgreSQL database dump
--

SET client_encoding = 'UTF8';
SET check_function_bodies = false;
SET client_min_messages = warning;

SET search_path = public, pg_catalog;

--
-- Name: validationrules_ruleid_seq; Type: SEQUENCE SET; Schema: public; Owner: www-data
--

SELECT pg_catalog.setval(pg_catalog.pg_get_serial_sequence('validationrules', 'ruleid'), 1, false);


--
-- Data for Name: validationrules; Type: TABLE DATA; Schema: public; Owner: www-data
--

COPY validationrules (ruleid, vrclassname, description, modulename) FROM stdin;
\.


--
-- PostgreSQL database dump complete
--

--
-- Phil forgot some stuff... whoops!
--

INSERT INTO groups (name,description) VALUES ('All Users','All the users! All of them!');
INSERT INTO configs (name,description) VALUES ('default_cartset','The default cartset');
INSERT INTO configs (name,description) VALUES ('user_lastlogin','Time of the previous login');
INSERT INTO configs (name,description) VALUES ('user_curlogin','Time of the current login');

