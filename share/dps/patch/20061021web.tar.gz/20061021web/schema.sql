SET client_encoding = 'UTF8';
SET check_function_bodies = false;
SET client_min_messages = warning;

SET search_path = public, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
BEGIN TRANSACTION;

CREATE TABLE validationrules (
    ruleid serial NOT NULL,
    vrclassname character varying(45) DEFAULT ''::character varying NOT NULL,
    description text NOT NULL,
    modulename character varying(16) DEFAULT ''::character varying NOT NULL
);

ALTER TABLE ONLY validationrules
    ADD CONSTRAINT validationrules_pkey PRIMARY KEY (ruleid);

--

CREATE TABLE cmscontent (
    contentid serial NOT NULL,
    regionid integer DEFAULT 0 NOT NULL,
    "timestamp" integer DEFAULT 0 NOT NULL,
    content bytea NOT NULL,
    userid integer DEFAULT 0 NOT NULL
);

--

CREATE TABLE cmsregions (
    regionid serial NOT NULL,
    name character varying(32) DEFAULT ''::character varying NOT NULL,
    editrealm integer DEFAULT 0 NOT NULL,
    viewrealm integer DEFAULT 0 NOT NULL,
    inlinetoolbar character varying(16) DEFAULT 'Basic'::character varying NOT NULL,
    windowtoolbar character varying(16) DEFAULT 'Default'::character varying NOT NULL
);

ALTER TABLE ONLY cmsregions
    ADD CONSTRAINT cmsregions_name_key UNIQUE (name);

ALTER TABLE ONLY cmsregions
    ADD CONSTRAINT cmsregions_pkey PRIMARY KEY (regionid);

--

CREATE TABLE fieldvalidators (
    ruleid integer DEFAULT 0 NOT NULL,
    vrclassname character varying(45) DEFAULT ''::character varying NOT NULL,
    description text NOT NULL,
    modulename character varying(16) DEFAULT ''::character varying NOT NULL
);

--

CREATE TABLE formfields (
    fieldid serial NOT NULL,
    formname character varying(32) DEFAULT ''::character varying NOT NULL,
    fieldname character varying(32) DEFAULT ''::character varying NOT NULL,
    ruleid integer DEFAULT 0 NOT NULL,
    modulename character varying(16) DEFAULT ''::character varying NOT NULL
);

ALTER TABLE ONLY formfields
    ADD CONSTRAINT formfields_pkey PRIMARY KEY (fieldid);

--

CREATE TABLE forms (
    formid serial NOT NULL,
    formname character varying(32) DEFAULT ''::character varying NOT NULL,
    modelclass character varying(32) DEFAULT ''::character varying NOT NULL,
    modulename character varying(32) DEFAULT ''::character varying NOT NULL,
    realmid integer DEFAULT 0 NOT NULL,
    validatorname character varying(32),
    validatormodule character varying(32)
);

ALTER TABLE ONLY forms
    ADD CONSTRAINT forms_pkey PRIMARY KEY (formid);

--

CREATE TABLE logentries (
    entryid serial NOT NULL,
    message text NOT NULL,
    "level" character varying(16) DEFAULT ''::character varying NOT NULL,
    module character varying(16),
    notes text,
    notify_date timestamp(6) without time zone DEFAULT now() NOT NULL
);

ALTER TABLE ONLY logentries
    ADD CONSTRAINT logentries_pkey PRIMARY KEY (entryid);

--

CREATE TABLE realmgrouplink (
    groupid integer DEFAULT 0 NOT NULL,
    realmid integer DEFAULT 0 NOT NULL,
    allow character(1)
);

ALTER TABLE ONLY realmgrouplink
    ADD CONSTRAINT realmgrouplink_pkey PRIMARY KEY (groupid, realmid);

--

CREATE TABLE realms (
    realmid serial NOT NULL,
    name character varying(32) DEFAULT ''::character varying NOT NULL,
    parentid integer DEFAULT 0 NOT NULL,
    description character varying(128),
    depth smallint,
    realmpath character varying(255)
);

ALTER TABLE ONLY realms
    ADD CONSTRAINT realms_pkey PRIMARY KEY (realmid);

--

CREATE TABLE realmuserlink (
    userid serial NOT NULL,
    realmid integer DEFAULT 0 NOT NULL,
    allow character(1)
);

--

ALTER TABLE ONLY realmuserlink
    ADD CONSTRAINT realmuserlink_pkey PRIMARY KEY (userid, realmid);

--

CREATE TABLE sessions (
    sessionid serial NOT NULL,
    useragent character varying(128) DEFAULT ''::character varying NOT NULL,
    ip character varying(15) DEFAULT ''::character varying NOT NULL,
    rndidentifier character varying(14) DEFAULT ''::character varying NOT NULL,
    lastaccess character varying(12) DEFAULT ''::character varying NOT NULL
);

ALTER TABLE ONLY sessions
    ADD CONSTRAINT sessions_pkey PRIMARY KEY (sessionid);

--

CREATE TABLE sessionvalues (
    valueid serial NOT NULL,
    sessionid integer DEFAULT 0 NOT NULL,
    skey character varying(32) DEFAULT ''::character varying NOT NULL,
    svalue bytea NOT NULL
);

ALTER TABLE ONLY sessionvalues
    ADD CONSTRAINT sessionvalues_pkey PRIMARY KEY (valueid);

--

CREATE TABLE templates (
    templateid serial NOT NULL,
    filename character varying(32) DEFAULT ''::character varying NOT NULL,
    viewerclassname character varying(32) DEFAULT ''::character varying NOT NULL,
    realmid integer DEFAULT 0 NOT NULL,
    modulename character varying(16) DEFAULT ''::character varying NOT NULL
);

ALTER TABLE ONLY templates
    ADD CONSTRAINT templates_pkey PRIMARY KEY (templateid, filename);

END TRANSACTION;
