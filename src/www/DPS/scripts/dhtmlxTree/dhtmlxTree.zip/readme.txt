
Current version: 1.3 from May 16, 2006

============================================================================================

If you want to use dhtmlXTree in a commercial product, you have to buy a commercial license. 
Please contact us at info@scand.com

Some comments on commercial usage:

1.Commercial License allows you to use dhtmlXTree on unlimited number of Websites or sites 
but only in one commercial project(application). According to this license we provide you 
with support (consultations) and free-of-charge bug fixing during 1 month. 
This license costs $99. 

2.Enterprise License allows you to use dhtmlXTree in unlimited number of projects on condition 
that all of them are projects of one company. Support period is 1 year. 
This license costs $399.


According to both licenses you are allowed to make changes to the code of Software but Scand LLC 
still owns the code and you are not allowed to distribute changed code.

